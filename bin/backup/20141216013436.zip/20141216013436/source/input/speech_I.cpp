////////////////////////////////////////////////////////////////////////////////
//File:   speech_I.cpp
//Dir:    source/input/
//Date:   2014-09-29
//Author: Zachary Gill
//Implementation of SpeechInput
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes


//includes
#include "speech_I.h"
#include "../header/settings.h"


//namespaces
using namespace std;


//Constructors

SpeechInput::SpeechInput ()
{
  SpeechInput::name = "SPEECH";
  SpeechInput::console = true;
}


//Destructors

void SpeechInput::free ()
{
  //terminate systems

  Input::~Input();
}


//Other Functions

void SpeechInput::main ()
{
  SpeechInput::init();

  do {
    DELAY_LOOP;
    if (SpeechInput::active) {
      if (SpeechInput::collectInput()) {
        SpeechInput::done = false;
        //process input string
        SpeechInput::done = true;
      }
      //check systems?
    }
  } while (!terminate_);
  SpeechInput::free();
}

void SpeechInput::init ()
{
  if (!settings_.hasSettingGroup(SETTING_INPUT, "SPEECH"))
    SpeechInput::defaultSettings();

  //initiate speech recognition systems

  return;
}

void SpeechInput::defaultSettings()
{
  SettingGroup sg;
  sg.setName("SPEECH");
  sg.setType(SETTING_INPUT);
  sg.setFile(userLoc_ + "data/setting/input/speech.settings");
  sg.addSetting(Setting("ENABLED", true));
  settings_.addSettingGroup(sg);
}

bool SpeechInput::collectInput ()
{
  //add blips to buffer
  //when finished return true

  return false;
}