////////////////////////////////////////////////////////////////////////////////
//File:   bol_V.h
//Dir:    source/variable/
//Date:   2014-11-18
//Author: Zachary Gill
//Interface of BOL Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_BOL_H_
#define _DLA_SV_BOL_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double isBOL (std::string);


//shared function definitions
#include "../resource/common.h"


#endif