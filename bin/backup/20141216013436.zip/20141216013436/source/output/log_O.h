////////////////////////////////////////////////////////////////////////////////
//File:   log_O.h
//Dir:    source/output/
//Date:   2014-08-29
//Author: Zachary Gill
//Interface of LogOutput
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SO_LOG_H_
#define _DLA_SO_LOG_H_


//constants
#include "../resource/const.h"


//standard includes
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <Windows.h>


//includes
#include "../header/output.h"
#include "../header/settings.h"
#include "../header/user.h"


//class definitions
class LogOutput : public TextOutput
{
  public:
    LogOutput                           ();

    virtual void        main            ();
    virtual inline void init            ();
    virtual inline void defaultSettings ();
    virtual inline bool collectOutput   ();
    virtual inline void free            ();
};


//global variable definitions
extern bool                 terminate_;
extern std::string          log_;
extern int                  outputCount_;
extern std::vector<Output*> outputs_;
extern User                 user_;


//function definitions
void clearLog();


#endif