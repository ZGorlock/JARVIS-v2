////////////////////////////////////////////////////////////////////////////////
//File:   testing.h
//Dir:    source/resource/
//Date:   2014-10-21
//Author: Zachary Gill
//Interface of Testing
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SR_TESTING_H_
#define _DLA_SR_TESTING_H_


//constants
#include "../resource/const.h"


//functions
bool testing();


//shared function definitions
#include "../resource/common.h"


#endif