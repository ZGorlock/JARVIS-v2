////////////////////////////////////////////////////////////////////////////////
//File:   testing.cpp
//Dir:    source/resource/
//Date:   2014-12-11
//Author: Zachary Gill
//Implementation of Testing
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <array>
#include <vector>
#include <ctype.h>


//includes
#include "testing.h"

//#include "../header/settings.h"
#include "../header/contact.h"
#include "../header/input.h"
#include "../header/output.h"

#include "../resource/timer.h"
#include "../resource/crypto.h"


//namespaces
using namespace std;


//functions
bool testing()
{
  //string loc = "";
  //fstream fs;
  //fs.open("C:/ProgramData/DLA/loc", fstream::in);
  //getline(fs, loc);
  //fs.close();



  //system("PAUSE");
  return false;
  //return true;
}