////////////////////////////////////////////////////////////////////////////////
//File:   user.cpp
//Dir:    source/
//Date:   2014-12-16
//Author: Zachary Gill
//Implementation of User
////////////////////////////////////////////////////////////////////////////////


//constants
#include "resource/const.h"


//standard includes
#include <iostream>
#include <fstream>
#include <sstream>
#include <ostream>
#include <string>
#include <time.h>
#include <Windows.h>


//includes
#include "header/user.h"
#include "header/settings.h"
#include "header/contact.h"
#include "header/input.h"
#include "header/output.h"
#include "header/module.h"

#include "input/keyboard_I.h"

#include "resource/crypto.h"


//namespaces
using namespace std;


//Constructors

User::User()
{
  User::username = "";
  User::id = "";
  User::password = "";
  User::loc = "data/" + User::username + "/";
  User::info = Contact::Contact();
}


void User::newLogin(string username, string password, string pin, string website)
{
  Login temp;
  temp.username = username;
  temp.password = password;
  temp.pin = pin;
  temp.website = website;
  User::addLogin(temp);
}
void User::newLogin(istream& is)
{
  Login temp;
  getline(is, temp.username);
  getline(is, temp.password);
  getline(is, temp.pin);
  getline(is, temp.website);
  User::addLogin(temp);
}


//Destructors

User::~User()
{
}

void User::free()
{
  User::~User();
}


//Accessors

string User::getUsername() const
{
  return User::username;
}

string User::getId() const
{
  return User::id;
}

Contact::DLA User::getDla() const
{
  return User::dla;
}

string User::getLoc() const
{
  return User::loc;
}

Contact User::getInfo() const
{
  return User::info;
}

Contact User::getContact(int element) const
{
  return User::contacts[element];
}


//Modifiers

void User::setUsername(string username)
{
  User::username = username;
}

void User::setId(string id)
{
  User::id = id;
}

void User::setPassword(string password)
{
  User::password = password;
}

void User::setDla(Contact::DLA dla)
{
  User::dla = dla;
}

void User::setLoc(string loc)
{
  User::loc = loc;
}

void User::setInfo(Contact info)
{
  User::info = info;
}

void User::addContact(Contact contact)
{
  User::contacts.push_back(contact);
}

void User::addLogin(Login login)
{
  User::logins.push_back(login);
}


//Other Functions

void User::loadUser()
{
  User::login();
  userLoc_ = User::getLoc();

  cls(hStdout_);

  fstream fs;
  stringstream ss;

  Contact::DLA dla;
  string tmpStr = "";

  fs.open(User::getLoc() + "data/id", fstream::in);
  getline(fs, tmpStr);
  User::setId(tmpStr);
  fs.close();

  fs.open(User::getLoc() + "data/dla", fstream::in);
  getline(fs, dla.name);
  getint (fs, dla.gender);
  User::setDla(dla);
  name_ = dla.name;
  gender_ = dla.gender;
  fs.close();

  User::loadUserFileS("data/info", ss);
  Contact info(ss);
  User::setInfo(info);
  ss.clear();

  if (User::isEncrypted("log")) {
    decryptFile(User::getLoc() + "log.log", User::password);
    fs.open(User::getLoc() + "log.crypt", fstream::out);
    fs << "0";
    fs.close();
  }
  
  User::loadUserFileS("data/contacts", ss);
  int contacts = 0;
  User::contacts.clear();
  getint(ss, contacts);
  while (contacts > 0) {
    Contact temp(ss);
    User::addContact(temp);
    getint(ss, contacts);
  }
  ss.clear();
  
  User::loadUserFileS("data/logins", ss);
  int logins = 0;
  User::logins.clear();
  getint(ss, logins);
  while (logins > 0) {
    User::newLogin(ss);
    getint(ss, logins);
  }
}

void User::login()
{
  vector<string> data;
  loadFileS("data/users", data);
  int in = 0;
  string tmpStr;
  int choice = 0;
  int a = 0;
  int b = 0;
  bool authenticated = false;;

  if (data.size() == 1) {
    do {
      User::setUsername(data[0]);
      User::setLoc("data/user/" + User::getUsername() + "/");
      
      tmpStr = "";
      cls(hStdout_);
      cout << "Log-in. Enter '' to go to the users' screen." << endl << endl;
      cout << "Username: " << User::getUsername() << endl;
      GUITHREADINFO gti;
      gti.cbSize = sizeof(GUITHREADINFO);
      bool isForeground = false;
      do {
        DELAY_LOOP;

        COORD coordScreen = { 0, 3 };
        SetConsoleCursorPosition(hStdout_, coordScreen);

        cout << "Password: ";
        if (showPassword_) {
          cout << tmpStr;
        }
        else {
          for (size_t i = 0; i < tmpStr.length(); i++)
            cout << "*";
        }
        
        GetGUIThreadInfo(NULL, &gti);
        if (gti.hwndFocus == hWnd_)
          isForeground = true;
        else
          isForeground = false;

        if (isForeground) {
          if (in = INKEY()) {
            if (in == 8) {
              if (tmpStr.length() > 0) {
                coordScreen = { (9 + (int)tmpStr.length()), 3 };
                SetConsoleCursorPosition(hStdout_, coordScreen);
                cout << " ";
                SetConsoleCursorPosition(hStdout_, coordScreen);
                tmpStr = tmpStr.substr(0, tmpStr.length() - 1);
              }
            }
            else if (in != 13) {
              if (tmpStr.length() < MAX_PASSWORD_LEN)
                tmpStr += str((char)in);
            }
          }
        }
      } while (in != 13);
      if (tmpStr > "") {
        User::setPassword(tmpStr);
        authenticated = User::authenticateUser();
      }
    } while (tmpStr > "" && !authenticated);
  }

  if (!authenticated) {
    do {
      do {
        cls(hStdout_);
        cout << "0 - Other Options" << endl;
        for (size_t i = 0; i < data.size(); i++)
          cout << i + 1 << " - " << data[i] << endl;
        cout << ": ";
        getline(cin, tmpStr);
        choice = val(tmpStr);
      } while (choice >(int)data.size() && choice != 0);

      switch (choice) {
      case 0:
        do {
          cls(hStdout_);
          cout << "0 - Return" << endl
            << "1 - New User" << endl
            << "2 - Delete User" << endl
            << "3 - Backup User" << endl
            << ": ";
          getline(cin, tmpStr);
          a = val(tmpStr);
          switch (a) {
          case 0:
            break;
          case 1:
            createUser();
            data.clear();
            loadFileS("data/users", data);
            break;
          case 2:
            do {
              cls(hStdout_);
              cout << "Delete User:" << endl;
              for (size_t i = 0; i < data.size(); i++)
                cout << "[" << i + 1 << "] - " << data[i] << endl;
              cout << endl
                << "0 - Return" << endl
                << "X - Delete User [X]" << endl << endl;
              cout << ": ";
              getline(cin, tmpStr);
              b = val(tmpStr);
              switch (b) {
              case 0:
                break;
              default:
                if (b > 0 && b < (int)data.size() + 1) {
                  User::setUsername(data[b - 1]);
                  User::setLoc("data/user/" + User::getUsername() + "/");
                  cls(hStdout_);
                  cout << "Username: " << User::getUsername() << endl
                    << "Password: ";
                  getline(cin, tmpStr);
                  User::setPassword(tmpStr);
                  if (User::authenticateUser()) {
                    User::deleteUser();
                    data.clear();
                    loadFileS("data/users", data);
                  }
                }
              }
            } while (b > 0);
            break;
          case 3:
            do {
              cls(hStdout_);
              cout << "Backup User:" << endl;
              for (size_t i = 0; i < data.size(); i++)
                cout << "[" << i + 1 << "] - " << data[i] << endl;
              cout << endl
                << "0 - Return" << endl
                << "X - Backup User [X]" << endl << endl;
              cout << ": ";
              getline(cin, tmpStr);
              b = val(tmpStr);
              switch (b) {
              case 0:
                break;
              default:
                if (b > 0 && b < (int)data.size() + 1) {
                  User::setUsername(data[b - 1]);
                  User::setLoc("data/user/" + User::getUsername() + "/");
                  cls(hStdout_);
                  cout << "Username: " << User::getUsername() << endl
                    << "Password: ";
                  getline(cin, tmpStr);
                  User::setPassword(tmpStr);
                  if (User::authenticateUser()) {
                    User::backupUser();
                    cls(hStdout_);
                    cout << "A backup of " << User::getUsername() << " has been made." << endl;
                    system("PAUSE");
                  }
                }
              }
            } while (b > 0);
            break;
          }
        } while (a > 0);
        break;
      default:
        User::setUsername(data[choice - 1]);
        User::setLoc("data/user/" + User::getUsername() + "/");

        tmpStr = "";
        while (INKEY()) {}
        cls(hStdout_);
        cout << "Log-in. Enter '' to go to the users' screen." << endl << endl;
        cout << "Username: " << User::getUsername() << endl;
        GUITHREADINFO gti;
        gti.cbSize = sizeof(GUITHREADINFO);
        bool isForeground = false;
        do {
          DELAY_LOOP;

          COORD coordScreen = { 0, 3 };
          SetConsoleCursorPosition(hStdout_, coordScreen);

          cout << "Password: ";
          if (showPassword_) {
            cout << tmpStr;
          }
          else {
            for (size_t i = 0; i < tmpStr.length(); i++)
              cout << "*";
          }

          GetGUIThreadInfo(NULL, &gti);
          if (gti.hwndFocus == hWnd_)
            isForeground = true;
          else
            isForeground = false;

          if (isForeground) {
            if (in = INKEY()) {
              if (in == 8) {
                tmpStr = tmpStr.substr(0, tmpStr.length() - 1);
                cls(hStdout_);
              }
              else if (in != 13) {
                if (tmpStr.length() < MAX_PASSWORD_LEN)
                  tmpStr += str((char)in);
              }
            }
          }
        } while (in != 13);
        if (tmpStr > "") {
          User::setPassword(tmpStr);
          authenticated = User::authenticateUser();
        }
      }
    } while (!authenticated);
  }
  authenticated = false;

  User::setPassword(tmpStr);
  tmpStr = "";
}


void User::backupUser()
{
  string source = loc_ + "data/user/" + User::getUsername();
  string backup = "data/backup/user/" + lCase(User::getUsername()) + "/" + str((int)time(0));
  string dest = loc_ + backup;
  copyFolder(source, dest);
  runBatch("bin/batch/zip.bat", vector<string>{backup + ".zip", backup, "1"});
}


void User::changePassword()
{
  pauseInputs();
  pauseOutputs();

  string tmpStr = "";
  string password = "";
  string verify = "";
  string hash = "";
  bool verified1 = true;
  bool verified2 = true;
  int iterations;

  do {
    cls(hStdout_);
    if (!verified1)
      cout << "This password is incorrect, please try again." << endl;
    cout << "Enter your current password. Enter '' to cancel." << endl
         << "Current Password: ";
    getline(cin, tmpStr);
    if (tmpStr == "") {
      startOutputs();
      startInputs();
      return;
    }
    verified1 = verifyPassword(tmpStr, User::getLoc() + "pass");
  } while (!verified1);
  
  do {
    do {
      cls(hStdout_);
      if (!verified2)
        cout << "The passwords you entered did not match, please try again." << endl;
      cout << "Create a New Password." << endl
           << "New Password: ";
      getline(cin, password);
    } while (password == "");
    iterations = randIterations();
    do {
      cls(hStdout_);
      cout << "Reenter your Password to Verify." << endl
           << "Password: ";
      getline(cin, verify);
    } while (verify == "");
    verified2 = (verify == password);
  } while (!verified2);

  User::backupUser();

  hash = passHasher(password, User::getUsername() + User::getId(), iterations, NULL);
  savePassword(User::getLoc() + "pass", hash, User::getUsername() + User::getId(), iterations);
  User::registerPassword(hash, iterations);

  cls(hStdout_);
  cout << "Your password has been changed." << endl;
  system("PAUSE");
  cls(hStdout_);

  startOutputs();
  startInputs();
}

void User::resetPassword()
{
  //reset user password
}


void User::loadUserInputs() const
{
  loadInputs(User::getUsername());
}

void User::loadUserOutputs() const
{
  loadOutputs(User::getUsername());
}

void User::loadUserModules() const
{
  loadModules(User::getUsername());
}


void User::save()
{
  fstream fs;
  stringstream ss;

  User::info.save(ss);
  User::printUserFileS("data/info", ss);
  ss.clear();
  
  if (User::isDecrypted("log")) {
    encryptFile(User::getLoc() + "log.log", User::password);
    fs.open(User::getLoc() + "log.crypt", fstream::out);
    fs << "1";
    fs.close();
  }
  
  for (size_t i = 0; i < User::contacts.size(); i++) {
    ss << i << endl;
    User::contacts[i].save(ss);
  }
  ss << "0";
  User::printUserFileS("data/contacts", ss);
  ss.clear();
  
  for (size_t i = 0; i < User::logins.size(); i++) {
    ss << i << endl;
    ss << User::logins[i].username << endl
       << User::logins[i].password << endl
       << User::logins[i].pin      << endl
       << User::logins[i].website  << endl;
  }
  ss << "0";
  User::printUserFileS("data/logins", ss);
  ss.clear();
}

void User::dump() const
{
  User::dump(cout);
}
void User::dump(ostream& stream) const
{
  stream << "Username: " << User::getUsername() << endl
         << "Id: "       << User::getId()       << endl
         << "Loc: "      << User::getLoc()      << endl << endl;
  User::getInfo().dump();
}


//Private Functions

User::Login User::getLogin(int element)
{
  return User::logins[element];
}


void User::createUser()
{
  string username = "";
  string id = "";
  string password = "";
  string hash = "";
  string verify = "";
  int iterations = 0;
  bool verifiedUsername = true;
  bool verifiedPassword = true;
  bool registered = true;
  
  do {
    cls(hStdout_);
    if (!verifiedUsername)
      cout << "The username you entered is unusable or taken, please try another." << endl;
    cout << "Create a Username." << endl
         << "Username: ";
    getline(cin, username);
    User::setUsername(username);
    verifiedUsername = User::verifyUsername();
  } while (!verifiedUsername);
  User::setLoc("data/user/" + username + "/");
  User::populateUserDirectory();

  id = generateGuid();
  fstream saveId;
  saveId.open(User::getLoc() + "data/id", fstream::out);
  saveId << id;
  saveId.close();
  
  do {
    do {
      cls(hStdout_);
      if (!verifiedPassword)
        cout << "The passwords you entered did not match, please try again." << endl;
      cout << "Create a Password." << endl
           << "Password: ";
      getline(cin, password);
    } while (password == "");
    iterations = randIterations();
    do {
      cls(hStdout_);
      cout << "Reenter your Password to Verify." << endl
           << "Password: ";
      getline(cin, verify);
    } while (verify == "");
    verifiedPassword = (verify == password);
  } while (!verifiedPassword);

  hash = passHasher(password, username + id, iterations, NULL);
  savePassword(User::getLoc() + "pass", hash, username + id, iterations);
  User::setPassword(password);

  fstream fs;
  stringstream ss;
  
  User::createDla();
  fs.open(User::getLoc() + "data/dla", fstream::out);
  fs << User::getDla().name << endl
     << User::getDla().gender << endl;
  fs.close();
  /////
  vector<string> modules;
  User::selectModules(modules);
  fs.open(User::getLoc() + "modules", fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs << modules[i] << endl;
  fs.close();

  User::populateSettings();

  Contact info;
  info.setUsername(User::getUsername());
  info.setId(id);
  info.setDla(User::getDla());
  info.edit();
  info.save(ss);
  User::printUserFileS("data/info", ss);

  vector<string> data;
  data.push_back("0");
  User::printUserFileS("data/contacts", data);
  User::printUserFileS("data/logins", data);

  encryptFile(User::getLoc() + "log.log", password);
  fs.open(User::getLoc() + "log.crypt", fstream::out);
  fs << "1";
  fs.close();

  User::registerUser(hash, iterations);

  fs.open("data/users", fstream::app);
  fs << username << endl;
  fs.close();
}

void User::deleteUser()
{
  int a = 0;
  
  cls(hStdout_);
  cout << "Are you sure you want to permanently delete the account [" << User::getUsername() << "]" << endl
       << "This action cannot easily be undone!" << endl << endl
       << "0 - Cancel" << endl
       << "1 - Yes, I understand. Delete this account." << endl
       << ": ";
  getint(cin, a);

  if (a == 1) {
    User::backupUser();

    if (deleteFolder(loc_ + "data/user/" + User::getUsername())) {
      vector<string> users;
      loadFileS("data/users", users);
      for (size_t i = 0; i < users.size(); i++) {
        if (users[i] == User::getUsername())
          users.erase(users.begin() + i);
      }
      printFileS("data/users", users);
    }

  }
}


void User::populateUserDirectory()
{
  makeFolder(User::getLoc());
  makeFolder(User::getLoc() + "backup");
  makeFolder(User::getLoc() + "backup/module");
  makeFolder(User::getLoc() + "data");
  makeFolder(User::getLoc() + "data/module");
  makeFolder(User::getLoc() + "data/setting");
  makeFolder(User::getLoc() + "data/setting/input");
  makeFolder(User::getLoc() + "data/setting/module");
  makeFolder(User::getLoc() + "data/setting/output");
  makeFolder(User::getLoc() + "input");
  makeFolder(User::getLoc() + "module");
  makeFolder(User::getLoc() + "output");

  makeFile(User::getLoc() + "log.log");
  makeFile(User::getLoc() + "log.crypt");
  makeFile(User::getLoc() + "data/contacts");
  makeFile(User::getLoc() + "data/dla");
  makeFile(User::getLoc() + "data/id");
  makeFile(User::getLoc() + "data/info");
  makeFile(User::getLoc() + "data/logins");
  makeFile(User::getLoc() + "input/ptrs");
  makeFile(User::getLoc() + "module/ptrs");
  makeFile(User::getLoc() + "output/ptrs");
  
  copyFile("data/backup/defaultinputs",  User::getLoc() + "inputs");
  copyFile("data/backup/defaultmodules", User::getLoc() + "modules");
  copyFile("data/backup/defaultoutputs", User::getLoc() + "outputs");
}

void User::populateSettings()
{
  copyFile("data/setting/settings.settings", User::getLoc() + "data/setting/settings.settings");
  
  vector<string> modules;
  loadFileS(User::getLoc() + "modules", modules);
  for (size_t i = 0; i < modules.size(); i++)
    copyFile("data/setting/module/" + lCase(modules[i]) + ".settings", User::getLoc() + "data/setting/module/" + lCase(modules[i]) + ".settings");

  vector<string> inputs;
  loadFileS(User::getLoc() + "inputs", inputs);
  for (size_t i = 0; i < inputs.size(); i++)
    copyFile("data/setting/input/" + lCase(inputs[i]) + ".settings", User::getLoc() + "data/setting/input/" + lCase(inputs[i]) + ".settings");

  vector<string> outputs;
  loadFileS(User::getLoc() + "outputs", outputs);
  for (size_t i = 0; i < outputs.size(); i++)
    copyFile("data/setting/output/" + lCase(outputs[i]) + ".settings", User::getLoc() + "data/setting/output/" + lCase(outputs[i]) + ".settings");
}


bool User::authenticateUser()
{
  return verifyPassword(User::password, User::getLoc() + "pass");
}

bool User::verifyUsername()
{
  if (User::getUsername() == "")
    return false;
  
  //test against server

  vector<string> users;
  loadFileS("data/users", users);
  for (size_t i = 0; i < users.size(); i++) {
    if (users[i] == User::getUsername())
      return false;
  }

  return true;
}

void User::registerUser(std::string hash, int iterations)
{
  string username = User::getUsername();
  string id = User::getId();

  //send username / id to server

  User::registerPassword(hash, iterations);
}

void User::registerPassword(std::string hash, int iterations)
{
  //send hash / iterations to server
}


void User::createDla ()
{
  Contact::DLA dla;
  dla.name = "NULL";
  dla.gender = GENDER_DEFAULT;

  string tmpStr = "";
  string tmpName = "";
  int tmpInt = 0;
  int a = 0;
  int b = 0;

  do {
    cls(hStdout_);
    cout << "Now you will create your specific DLA." << endl << endl
         << "Would you like me to be male or female?" << endl
         << "1 - Male" << endl
         << "2 - Female" << endl << endl
         << ": ";
    getline(cin, tmpStr);
    tmpInt = val(tmpStr);
    switch (tmpInt) {
      case 1:
        dla.gender = GENDER_MALE;
        break;
      case 2:
        dla.gender = GENDER_FEMALE;
        break;
    }
  } while (dla.gender == GENDER_DEFAULT);

  switch (dla.gender) {
    case 1:
      tmpName = names_boy_[rand() % (int)names_boy_.size()];
      break;
    case 2:
      tmpName = names_girl_[rand() % (int)names_girl_.size()];
      break;
  }

  do {
    cls(hStdout_);
    cout << "Now you will create your specific DLA." << endl << endl
         << "I have chosen the name " << tmpName << "." << endl
         << "Are you ok with that name?" << endl
         << "0 - Yes, your name will be " << tmpName << endl
         << "1 - No, select another name" << endl
         << "2 - No, let me enter a name for you" << endl
         << ": ";
    getline(cin, tmpStr);
    a = val(tmpStr);

    switch (a) {
      case 0:
        dla.name = tmpName;
        break;
      case 1:
        switch (dla.gender) {
          case 1:
            tmpName = names_boy_[rand() % (int)names_boy_.size()];
            break;
          case 2:
            tmpName = names_girl_[rand() % (int)names_girl_.size()];
            break;
        }
        break;
      case 2:
        do {
          cls(hStdout_);
          cout << "Enter a name for me. Enter '' to return." << endl
               << ": ";
          getline(cin, tmpStr);
          if (tmpStr == "")
            break;
          tmpName = tmpStr;
          cls(hStdout_);
          cout << "Are you sure you want my name to be " << tmpName << "?" << endl
            << "0 - Yes, your name will be " << tmpName << endl
            << "1 - No, let me enter another name" << endl
            << "2 - No, return" << endl
            << ": ";
          cin >> b;
          getline(cin, tmpStr);
          if (b == 2)
            break;
        } while (b > 0);
        if (b == 2)
          break;
        dla.name = tmpName;
        break;
    }
  } while (dla.name == "NULL");

  User::setDla(dla);
}

void User::selectModules(vector<string>& modules)
{
  vector<string> availableModules;
  loadFileS("data/modules", availableModules);

  modules.clear();
  loadFileS("data/modules", modules);
  
  vector<string> moduleOptions;
  string tmpStr = "";
  bool has = false;
  int a = 0;
  int b = 0;

  do {
    cls(hStdout_);
    cout << "Now you will select which modules to add to your DLA." << endl
         << "This is for advanced users, we recommend you just enter '0' to select all modules." << endl << endl;
    cout << "0 - Done selecting modules" << endl
         << "1 - View Selected Modules" << endl
         << "2 - Select a Module" << endl
         << "3 - Deselect a Module" << endl
         << "4 - Select all Modules" << endl
         << "5 - Deselect all Modules" << endl
         << ": ";
    getline(cin, tmpStr);
    a = val(tmpStr);
    switch (a) {
      case 0:
        break;
      case 1:
        cls(hStdout_);
        cout << "Modules you have selected:" << endl;
        for (size_t i = 0; i < modules.size(); i++)
          cout << "  " << modules[i] << endl;
        system("PAUSE");
        break;
      case 2:
        do { 
          moduleOptions.clear();
          for (size_t i = 0; i < availableModules.size(); i++) {
            has = false;
            for (size_t j = 0; j < modules.size(); j++) {
              if (modules[j] == availableModules[i])
                has = true;
            }
            if (!has)
              moduleOptions.push_back(availableModules[i]);
          }
          cls(hStdout_);
          cout << "Available Modules:" << endl;
          if (moduleOptions.size() == 0) {
            cout << "All modules are already selected, enter '0'." << endl;
          }
          else {
            for (size_t i = 0; i < moduleOptions.size(); i++)
              cout << "[" << i + 1 << "] - " << moduleOptions[i] << endl;
          }
          cout << endl
               << "0 - Done Selecting Modules" << endl
               << "X - Select Module [X]" << endl;
          cin >> b;
          getline(cin, tmpStr);
          switch (b) {
            case 0:
              break;
            default:
              if (inRange(b, 0, (int)moduleOptions.size() + 1, false, false)) {
                modules.push_back(moduleOptions[b - 1]);
                cls(hStdout_);
                cout << "The " << moduleOptions[b - 1] << " module has been selected." << endl;
                system("PAUSE");
              }
          }
        } while (b > 0);
        break;
      case 3:
        do {
          cls(hStdout_);
          cout << "Selected Modules:" << endl;
          if (modules.size() == 0) {
            cout << "All modules are already deselected, enter '0'." << endl;
          }
          else {
            for (size_t i = 0; i < modules.size(); i++)
              cout << "[" << i + 1 << "] - " << modules[i] << endl;
          }
          cout << endl
               << "0 - Done Deselecting Modules" << endl
               << "X - Deselect Module [X]" << endl;
          cin >> b;
          getline(cin, tmpStr);
          switch (b) {
            case 0:
              break;
            default:
              if (inRange(b, 0, (int)modules.size() + 1, false, false)) {
                tmpStr = modules[b - 1];
                modules.erase(modules.begin() + b - 1);
                cls(hStdout_);
                cout << "The " << tmpStr << " module has been deselected." << endl;
                system("PAUSE");
              }
          }
        } while (b > 0);
        break;
      case 4:
        modules.clear();
        for (size_t i = 0; i < availableModules.size(); i++)
          modules.push_back(availableModules[i]);
        cls(hStdout_);
        cout << "All modules have been selected." << endl;
        system("PAUSE");
        break;
      case 5:
        modules.clear();
        cls(hStdout_);
        cout << "All modules have been deselected." << endl;
        system("PAUSE");
        break;
    }
  } while (a > 0);
}


void User::loadUserFileS(string file, vector<string>& data, int& dataLen)
{
  file = User::getLoc() + file;
  
  if (!fileExists(file) || fileSize(file) < 1)
    return;

  loadEncFileS(file, User::password, data, dataLen);
}
void User::loadUserFileS(string file, ostream& ss)
{
  vector<string> data;
  int dataLen = 0;
  User::loadUserFileS(file, data, dataLen);

  for (int i = 0; i < dataLen; i++)
    ss << data[i] << endl;
}

void User::printUserFileS(string file, vector<string>& data)// const
{
  file = User::getLoc() + file;

  if (!fileExists(file))
    makeFile(file);

  printEncFileS(file, User::password, data);
}
void User::printUserFileS(string file, istream& ss)// const
{
  string tmpStr = "";
  vector<string> data;
  while (getline(ss, tmpStr))
    data.push_back(tmpStr);

  User::printUserFileS(file, data);
}


bool User::isEncrypted(string file) const
{
  int result;
  fstream fs;
  fs.open(User::getLoc() + file + ".crypt");
  getint(fs, result);
  if (result == 1)
    return true;
  return false;
}

bool User::isDecrypted(string file) const
{
  int result;
  fstream fs;
  fs.open(User::getLoc() + file + ".crypt");
  getint(fs, result);
  if (result == 0)
    return true;
  return false;
}


//functions
string getAlias()
{
  if (user_.getInfo().getName().nickName > "")
    return user_.getInfo().getName().nickName;
  else
    return user_.getInfo().name_toString();
}