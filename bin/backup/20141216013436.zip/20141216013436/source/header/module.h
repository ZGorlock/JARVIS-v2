////////////////////////////////////////////////////////////////////////////////
//File:   module.h
//Dir:    source/header/
//Date:   2014-11-16
//Author: Zachary Gill
//Interface of Module
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SH_MODULE_H_
#define _DLA_SH_MODULE_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>
#include <vector>
#include <map>


//includes
#include "command.h"


//typedefs
typedef std::string (*CmdPtr)();


//class definitions
class Module
{
  public:
    //Constructors
    Module ();
    Module (std::string, std::string, double);
    Module (std::string);

    //Destructors
    ~Module();
    void free();

    //Accessors
    std::string              getName          () const;
    std::string              getDescription   () const;
    double                   getPriority      () const;
    std::vector<std::string> getKeywords      () const;
    std::vector<std::string> getDependencies  () const;
    std::vector<std::string> getVariables     () const;
    int                      getCommandCount  () const;
    std::vector<Command>     getCommands      () const;
    int                      getHighestBidder () const;

    //Modifiers
    void setPriority (double);

    //Other Functions
    void        addCommand (Command);
    bool        hasKeyword (std::string) const;
    double      queue      ();
    double      queue      (std::string);
    void        queue_     (std::string, double&);
    std::string execute    () const;
    void        dump       () const;
    void        dump       (std::ostream&) const;
    void        dump       (std::string) const;
    void        dump       (std::ostream&, std::string) const;

    double oPriority;

  private:
    std::string              name;
    std::string              description;
    double                   priority;
    std::vector<std::string> keywords;
    std::vector<std::string> dependencies;
    std::vector<std::string> variables;
    int                      commandCount;
    std::vector<Command>     commands;
    int                      highestBidder;
} ;


//global variable definitions
extern int                           moduleCount_;
extern std::string                   request_;
extern std::string                   response_;
extern int                           variableCount_;
extern std::vector<Module>           modules_;
extern std::vector<std::string>      variables_;
extern std::vector<std::string>      variableTypes_;
extern std::vector<std::string>      moduleList_;
extern std::vector<std::string>      variableList_;
extern std::map<std::string, CmdPtr> CommandPtrs_;


//resources
#include "../resource/modules"


//function definitions
void    loadModules  ();
void    loadModules  (std::string);
bool    hasModule    (std::string);
void    setOPriority (std::string, double);


//shared function definitions
#include "../resource/common.h"


#endif