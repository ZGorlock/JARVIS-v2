////////////////////////////////////////////////////////////////////////////////
//File:   module.cpp
//Dir:    source/
//Date:   2014-11-16
//Author: Zachary Gill
//Implementation of Module
////////////////////////////////////////////////////////////////////////////////


//constants
#include "resource/const.h"


//standard includes
#include <iostream>
#include <fstream>
#include <sstream>
#include <ostream>
#include <string>
#include <vector>
#include <map>

#include <boost/thread/thread.hpp>


//includes
#include "header/module.h"
#include "header/variable.h"


//namespaces
using namespace std;


//Constructors

Module::Module ()
{
  Module::name = "";
  Module::description = "";
  Module::priority = 0.0;
  Module::commandCount = 0;

  moduleCount_ ++;
}
Module::Module (string name, string description, double priority)
{
  Module::name = name;
  Module::description = description;
  Module::priority = priority;
  Module::commandCount = 0;

  Module::priority /= 100;

  moduleCount_ ++;
}
Module::Module (string modfile)
{
  modfile = "data/" + modfile + ".module";
  if (fileExists(modfile)) {
    fstream moduleFile;
    moduleFile.open(modfile.c_str(), fstream::in);

    if (moduleFile.is_open()) {
      string tmp = "";

      getline  (moduleFile, Module::name);
      getline  (moduleFile, Module::description);
      getdouble(moduleFile, Module::priority);
      
      getline  (moduleFile, tmp);
      stringstream ss0(tmp);
      string token0;
      while (getline(ss0, token0, ','))
        Module::keywords.push_back(uCase(token0));

      getline  (moduleFile, tmp);
      stringstream ss1(tmp);
      string token1;
      while (getline(ss1, token1, ','))
        Module::dependencies.push_back(uCase(token1));
      
      getline  (moduleFile, tmp);
      stringstream ss2(tmp);
      string token2;
      while (getline(ss2, token2, ','))
        Module::variables.push_back(uCase(token2));

      Module::commandCount = 0;
      int nextCommand = 0;
      getint(moduleFile, nextCommand);
      while (nextCommand != 0) {
        Module::commandCount = nextCommand;

        Command tmpCommand (moduleFile);
        Module::commands.push_back(tmpCommand);

        getint(moduleFile, nextCommand);
      }

      moduleFile.close();
    }
  }
  else {
    Module::name = "";
    Module::description = "";
    Module::priority = 0.0;
    Module::commandCount = 0;
  }

  Module::priority /= 100;

  moduleCount_ ++;
}


//Destructors

Module::~Module ()
{
}

void Module::free ()
{
  for (size_t i = 0; i < Module::commands.size(); i ++)
    Module::commands[i].free();

  Module::~Module();
  moduleCount_ --;
}


//Accessors

string Module::getName () const
{
  return Module::name;
}

string Module::getDescription () const
{
  return Module::description;
}

double Module::getPriority () const
{
  return Module::priority;
}

vector<string> Module::getKeywords () const
{
  return Module::keywords;
}

vector<string> Module::getDependencies () const
{
  return Module::dependencies;
}

vector<string> Module::getVariables() const
{
  return Module::variables;
}

int Module::getCommandCount () const
{
  return Module::commandCount;
}

vector<Command> Module::getCommands () const
{
  return Module::commands;
}

int Module::getHighestBidder () const
{
  return Module::highestBidder;
}


//Modifiers

void Module::setPriority (double priority)
{
  Module::priority = priority;
}


//Other Functions

void Module::addCommand (Command command)
{
  Module::commandCount ++;
  Module::commands.push_back(command);
}

bool Module::hasKeyword(string keyword) const
{
  keyword = uCase(keyword);
  for (size_t i = 0; i < Module::keywords.size(); i++) {
    if (Module::keywords[i] == keyword)
      return true;
  }
  return false;
}

double Module::queue ()
{
  return Module::queue(request_);
}
double Module::queue (string query)
{
  Module::highestBidder = 0;
  double bid            = 0.0;
  double highestBid     = 0.0;

  vector<double> bids(Module::commandCount);

  fstream fs;
  bool output_command_score = settings_.getSettingB(SETTING_METRIC, "METRICS", "OUTPUT_COMMAND_SCORE");
  if (output_command_score)
    fs.open("temp/commandScore.txt", fstream::app);
  
  if (settings_.getSettingB(SETTING_METRIC, "METRICS", "COMMAND_SCORE_MT")) {
    boost::thread_group scoreThreads;
    for (int i = 0; i < Module::commandCount; i++) {
      boost::thread *t = new boost::thread(&Command::score_, &Module::commands[i], query, boost::ref(bids[i]));
      scoreThreads.add_thread(t);
    }
    scoreThreads.join_all();
    for (int i = 0; i < Module::commandCount; i++) {
      if (output_command_score)
        fs << Module::name << ":" << Module::commands[i].getName() << " - " << bids[i] << endl;

      if (bids[i] > highestBid) {
        Module::highestBidder = i;
        highestBid = bids[i];
      }
    }
  }
  else {
    for (int i = 0; i < Module::commandCount; i++) {
      bids[i] = Module::commands[i].score(query);

      if (output_command_score)
        fs << Module::name << ":" << Module::commands[i].getName() << " - " << bids[i] << endl;

      if (bids[i] > highestBid) {
        Module::highestBidder = i;
        highestBid = bids[i];
      }
    }
  }
  
  if (output_command_score)
    fs.close();
  
  return highestBid;
}
void Module::queue_(string query, double& out)
{
  out = Module::queue(query);
  return;
}

string Module::execute () const
{
  variables_.clear();
  variableTypes_.clear();
  for (size_t i = 0; i < Module::commands[Module::highestBidder].getVars().size(); i++) {
    variables_.push_back(Module::commands[Module::highestBidder].getVars()[i]);
    variableTypes_.push_back(Module::commands[Module::highestBidder].getVarTypes()[i]);
  }
  variableCount_ = variables_.size();
  return CommandPtrs_[Module::name + "::" + Module::commands[Module::highestBidder].getName()]();
}

void Module::dump () const
{
  Module::dump(cout);
}
void Module::dump (ostream& stream) const
{
  Module::dump(stream, "");
}
void Module::dump (string prefix) const
{
  Module::dump(cout, prefix);
}
void Module::dump (ostream& stream, string prefix) const
{
  stream << prefix << "Name: "             << Module::name                << endl
         << prefix << "Description: "      << Module::description         << endl
         << prefix << "Priority: "         << Module::priority            << endl
         << prefix << "Dependency Count: " << Module::dependencies.size() << endl
         << prefix << "Dependencies: "                                    << endl;

  for (size_t i = 0; i < Module::dependencies.size(); i ++)
    stream << prefix << "    " << Module::dependencies[i] << endl;

  stream << prefix << "Command Count: "    << Module::commandCount        << endl
         << prefix << "Commands: "                                        << endl;

  for (int i = 0; i < Module::commandCount; i ++) {
    stream << prefix << "    " << commands[i].getName() << endl;
    commands[i].dump(stream, prefix + "    " + "    ");
  }
}


//functions
void loadModules ()
{
  fstream fs;
  fs.open("data/modules", fstream::in);

  string moduleName = "";
  while (getline(fs, moduleName)) {
    Module tmpModule ("module/" + moduleName);
    modules_.push_back(tmpModule);
  }

  fs.close();
}
void loadModules(string username)
{
  loadFileS("data/user/" + username + "/modules", moduleList_);

  vector<string> modules;
  loadFileS("data/user/" + username + "/modules", modules);

  fstream fs;
  fs.open("data/user/" + username + "/module/ptrs", fstream::in);

  string moduleName = "";
  while (getline(fs, moduleName)) {
    if (fileExists("data/user/" + username + "/module/" + moduleName + ".module")) {
      Module tmpModule("user/" + username + "/module/" + moduleName);
      modules_.push_back(tmpModule);
      for (size_t i = 0; i < modules_[modules_.size() - 1].getVariables().size(); i++) {
        if (!hasVariable(modules_[modules_.size() - 1].getVariables()[i]))
          variableList_.push_back(modules_[modules_.size() - 1].getVariables()[i]);
      }
      vector<string> moduleCopy = modules;
      for (size_t i = 0; i < modules.size(); i++) {
        if (modules[i] != moduleName)
          moduleCopy.push_back(modules[i]);
      }
      modules = moduleCopy;
    }
  }

  fs.close();

  for (size_t i = 0; i < modules.size(); i++) {
    if (fileExists("data/module/" + modules[i] + ".module")) {
      Module tmpModule("module/" + modules[i]);
      modules_.push_back(tmpModule);
    }
  }
}

bool hasModule (string name)
{
  for (int i = 0; i < moduleCount_; i ++)
    if (modules_[i].getName() == name)
      return true;
  return false;
}

void setOPriority(string name, double oPriority)
{
  for (int i = 0; i < moduleCount_; i++)
    if (modules_[i].getName() == name)
      modules_[i].oPriority = oPriority;
}