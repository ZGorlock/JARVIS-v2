////////////////////////////////////////////////////////////////////////////////
//File:   module_editor.cpp
//Dir:    *
//Date:   2014-08-03
//Author: Zachary Gill
//Implementation of Module Editor
////////////////////////////////////////////////////////////////////////////////


//standard includes
#include <iostream>
#include <fstream>
#include <sstream>
#include <ostream>
#include <string>
#include <vector>
#include <map>
#include <ctime>
#include <cctype>
#include <algorithm>
#include <Windows.h>

#include <boost/algorithm/string.hpp>


//includes
#include "module_editor.h"


//namespaces
using namespace std;


//functions

int main ()
{
  int a0 = 0;
  int a1 = 0;
  int a = 0;
  int b = 0;
  int c = 0;
  int d = 0;
  int e = 0;
  int f = 0;
  int g = 0;
  int h = 0;
  int z = 0;
  string modfile = "";
  string modloc = "";
  string tmp = "";
  string loc = "";
  if (fileExists("C:/ProgramData/DLA/loc")) {
    fstream fs;
    fs.open("C:/ProgramData/DLA/loc", fstream::in);
    getline(fs, loc);
    fs.close();
  }
  else {
    return 1;
  }
  do {
    vector<string> modules;
    vector<string> moduleUser;
    vector<string> users;
    loadLists(loc, modules, moduleUser, users);
    cls(h_);
    cout << "Module Count: " << modules.size() << endl
         << "Modules" << endl;
    for (size_t i = 0; i < modules.size(); i ++)
      cout << "    " << modules[i] << endl;
    cout << endl
         << "0 - Done (close)" << endl
         << "1 - Edit Module" << endl
         << "2 - Add Module" << endl
         << "3 - Remove Module" << endl << endl
         << ": ";
    cin >> a0;
    switch (a0)
    {
      case 0 : 
        break;
      case 1 : 
        do {
          loadLists(loc, modules, moduleUser, users);
          cls(h_);
          cout << "Module Count: " << modules.size() << endl
               << "Modules" << endl;
          for (size_t i = 0; i < modules.size(); i ++)
            cout << "   [" << i + 1 << "] " << modules[i] << endl;
          cout << endl
               << "0 - Done Editing Modules" << endl
               << "X - Edit Module [X]" << endl << endl
               << ": ";
          cin >> a1;
          getline(cin, tmp);
          if (a1 > 0 && a1 <= (int) modules.size()) {
            string modfile = loc + "data/module/" + modules[a1 - 1] + ".module";
            Module m (modfile);
            do {
              cls(h_);
              m.dump();
              cout << "0  - Done Editing Module (Save)" << endl
                   << "1  - Change Name" << endl
                   << "2  - Edit Description" << endl
                   << "3  - Change Priority" << endl
                   << "4  - Edit Dependencies" << endl
                   << "5  - Edit Commands" << endl
                   << "6  - Organize Module" << endl
                   << "7  - Add to JARVIS" << endl
                   << "8  - Remove from JARVIS" << endl
                   << "9  - Add to User" << endl
                   << "10 - Remove from User" << endl
                   << "11 - Create User Copy" << endl << endl
                   << ": ";
              cin >> a;
              getline(cin, tmp);
              switch (a) {
                case 0 : 
                  modloc = loc + "data/module/" + modules[a1 - 1];
                  saveModule(m, loc, moduleUser[a1 - 1], modloc);
                  break;
                case 1 : 
                  cls(h_);
                  cout << "Old Name: " << m.name << endl
                       << "New Name: ";
                  getline(cin, tmp);
                  if (tmp > "") {
                    m.name = uCase(tmp);
                    for (int i = 0; i < m.commandCount; i ++)
                      m.commands[i].module = uCase(tmp);
                  }
                  break;
                case 2 : 
                  cls(h_);
                  cout << "Old Description: " << m.description << endl
                       << "New Description: ";
                  getline(cin, tmp);
                  if (tmp > "")
                    m.description = tmp;
                  break;
                case 3 : 
                  cls(h_);
                  cout << "Old Priority: " << m.priority << endl
                       << "New Priority: ";
                  cin >> m.priority;
                  for (int i = 0; i < m.commandCount; i ++)
                    m.commands[i].modulePriority = m.priority;
                  break;
                case 4 : 
                  do {
                    cls(h_);
                    cout << "Dependency Count: " << m.dependencies.size() << endl
                         << "Dependencies: "                              << endl;
                    for (size_t i = 0; i < m.dependencies.size(); i ++)
                      cout << "    " << m.dependencies[i] << endl;
                    cout << endl
                         << "0 - Done Editing Dependencies" << endl
                         << "1 - Add Dependency" << endl
                         << "2 - Remove Dependency" << endl
                         << "3 - Change Dependency Order" << endl
                         << "4 - Organize Dependencies" << endl << endl
                         << ": ";
                    cin >> b;
                    getline(cin, tmp);
                    switch (b)
                    {
                      case 0 : 
                        break;
                      case 1 : 
                        do {
                          cls(h_);
                          cout << "Dependency Count: " << m.dependencies.size() << endl
                               << "Dependencies: "                              << endl;
                          for (size_t i = 0; i < m.dependencies.size(); i ++)
                            cout << "    " << m.dependencies[i] << endl;
                          cout << endl
                               << "0 - Done Adding Dependencies" << endl
                               << "1 - Add a Dependency" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          switch (c)
                          {
                            case 0 : 
                              break;
                            case 1 : 
                              cls(h_);
                              cout << "Name of New Dependency: ";
                              getline(cin, tmp);
                              if (tmp > "") {
                                bool isnew = true;
                                for (size_t i = 0; i < m.dependencies.size(); i ++)
                                  if (m.dependencies[i] == tmp)
                                    isnew = false;
                                if (isnew)
                                  m.dependencies.push_back(uCase(tmp));
                              }
                              break;
                          }
                        } while (c > 0);
                        break;
                      case 2 : 
                        do {
                          cls(h_);
                          cout << "Dependency Count: " << m.dependencies.size() << endl
                               << "Dependencies: "                              << endl;
                          for (size_t i = 0; i < m.dependencies.size(); i ++)
                            cout << "    [" << i + 1 << "] " << m.dependencies[i] << endl;
                          cout << endl
                               << "0 - Done Removing Dependencies" << endl
                               << "X - Remove Dependency [X]" << endl << endl
                               << ": ";
                          cin >> c;
                          if (c > 0 && c <= (int) m.dependencies.size())
                            m.dependencies.erase(m.dependencies.begin() + c - 1);
                        } while (c > 0);
                        break;
                      case 3 : 
                        do {
                          cls(h_);
                          cout << "Dependency Count: " << m.dependencies.size() << endl
                               << "Dependencies: "                              << endl;
                          for (size_t i = 0; i < m.dependencies.size(); i ++)
                            cout << "    [" << i + 1 << "] " << m.dependencies[i] << endl;
                          cout << endl
                               << "0 - Done Moving Dependencies" << endl
                               << "X - Move Dependency [X]" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          if (c > 0 && c <= (int) m.dependencies.size()) {
                            cls(h_);
                            cout << "Dependency Count: " << m.dependencies.size() << endl
                                 << "Dependencies: "                              << endl;
                            for (size_t i = 0; i < (int) m.dependencies.size(); i ++)
                              cout << "    [" << i + 1 << "] " << m.dependencies[i] << endl;
                            cout << endl
                                 << "0 - Done Moving Dependency [" << c << "]" << endl
                                 << "1 - Move to Top" << endl
                                 << "2 - Move to Bottom" << endl
                                 << "3 - Move to a Position" << endl
                                 << "4 - Swap with a Position" << endl << endl
                                 << ": ";
                            cin >> d;
                            getline(cin, tmp);
                            switch (d)
                            {
                              case 0 : 
                                break;
                              case 1 : 
                                m.dependencies.insert(m.dependencies.begin(), m.dependencies[c - 1]);
                                m.dependencies.erase(m.dependencies.begin() + c);
                                break;
                              case 2 : 
                                m.dependencies.insert(m.dependencies.end(), m.dependencies[c - 1]);
                                m.dependencies.erase(m.dependencies.begin() + c - 1);
                                break;
                              case 3 : 
                                cls(h_);
                                cout << "Dependency Count: " << m.dependencies.size() << endl
                                     << "Dependencies: "                              << endl;
                                for (size_t i = 0; i < (int) m.dependencies.size(); i ++)
                                  cout << "    [" << i + 1 << "] " << m.dependencies[i] << endl;
                                cout << endl
                                     << "0 - Cancel Move" << endl
                                     << "X - Move to Position [X]" << endl << endl
                                     << ": ";
                                cin >> e;
                                getline(cin, tmp);
                                if (e > 0 && e <= (int) m.dependencies.size() && e != c) {
                                  m.dependencies.insert(m.dependencies.begin() + e - 1, m.dependencies[c - 1]);
                                  if (e < c)
                                    m.dependencies.erase(m.dependencies.begin() + c);
                                  else
                                    m.dependencies.erase(m.dependencies.begin() + c - 1);
                                }
                                break;
                              case 4 : 
                                cls(h_);
                                cout << "Dependency Count: " << m.dependencies.size() << endl
                                     << "Dependencies: "                              << endl;
                                for (size_t i = 0; i < (int) m.dependencies.size(); i ++)
                                  cout << "    [" << i + 1 << "] " << m.dependencies[i] << endl;
                                cout << endl
                                     << "0 - Cancel Swap" << endl
                                     << "X - Swap with Position [X]" << endl << endl
                                     << ": ";
                                cin >> e;
                                getline(cin, tmp);
                                if (e > 0 && e <= (int) m.dependencies.size() && e != c)
                                  swap(m.dependencies[c - 1], m.dependencies[e - 1]);
                                break;
                            }
                          }
                        } while (c > 0);
                        break;
                      case 4 : 
                        do {
                          cls(h_);
                          cout << "Dependency Count: " << m.dependencies.size() << endl
                               << "Dependencies: "                              << endl;
                          for (size_t i = 0; i < (int) m.dependencies.size(); i ++)
                            cout << "    " << m.dependencies[i] << endl;
                          cout << endl
                               << "0 - Done Organizing Models" << endl
                               << "1 - Organize Alphabetically" << endl
                               << "2 - Organize Alphabetically (Reverse)" << endl << endl
                               << ": ";                  
                          cin >> c;
                          getline(cin, tmp);
                          switch (c)
                          {
                            case 0 : 
                              break;
                            case 1 : 
                              for (size_t i = 0; i < m.dependencies.size(); i ++)
                                for (size_t j = 0; j < m.dependencies.size(); j ++)
                                  if (m.dependencies[j] > m.dependencies[i])
                                    swap(m.dependencies[j], m.dependencies[i]);
                              break;
                            case 2 : 
                              for (size_t i = 0; i < m.dependencies.size(); i ++)
                                for (size_t j = 0; j < m.dependencies.size(); j ++)
                                  if (m.dependencies[j] < m.dependencies[i])
                                    swap(m.dependencies[j], m.dependencies[i]);
                              break;
                          }
                        } while (c > 0);
                        break;
                    }
                  } while (b > 0);
                  break;
                case 5 : 
                  do {
                    cls(h_);
                    cout << "Command Count: " << m.commandCount << endl
                         << "Commands: "                        << endl;
                    for (int i = 0; i < m.commandCount; i ++)
                      cout << "    " << m.commands[i].name << endl;
                    cout << endl
                         << "0 - Done Editing Commands" << endl
                         << "1 - Edit Command" << endl
                         << "2 - Add Command" << endl
                         << "3 - Remove Command" << endl
                         << "4 - Swap Command Order" << endl
                         << "5 - Organize Commands" << endl << endl
                         << ": ";
                    cin >> b;
                    getline(cin, tmp);
                    switch (b)
                    {
                      case 0 : 
                        break;
                      case 1 : 
                        do {
                          cls(h_);
                          cout << "Command Count: " << m.commandCount << endl
                               << "Commands: "                        << endl;
                          for (int i = 0; i < m.commandCount; i ++)
                            cout << "   [" << i + 1 << "] " << m.commands[i].name << endl;
                          cout << endl
                               << "0 - Done Editing Commands" << endl
                               << "X - Edit Command X" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          if (c > 0 && c <= m.commandCount) {
                            Command& n = m.commands[c - 1];
                            do {
                              cls(h_);
                              n.dump();
                              cout << "0 - Done Editing Command [" << c << "]" << endl
                                   << "1 - Change Name" << endl
                                   << "2 - Edit Description" << endl
                                   << "3 - Edit Definition" << endl
                                   << "4 - Change Return Type" << endl
                                   << "5 - Change Priority" << endl
                                   << "6 - Edit Models" << endl
                                   << "7 - Change Output" << endl
                                   << "8 - Change Risk" << endl << endl
                                   << ": ";
                              cin >> d;
                              getline(cin, tmp);
                              switch (d)
                              {
                                case 0 : 
                                  break;
                                case 1 : 
                                  cls(h_);
                                  cout << "Old Name: " << n.name << endl
                                       << "New Name: ";
                                  getline(cin, tmp);
                                  if (tmp > "")
                                    n.name = tmp;
                                  break;
                                case 2 : 
                                  cls(h_);
                                  cout << "Old Description: " << n.description << endl
                                       << "New Description: ";
                                  getline(cin, tmp);
                                  if (tmp > "")
                                    n.description = tmp;
                                  break;
                                case 3 : 
                                  cls(h_);
                                  cout << "Old Definition: " << n.definition << endl
                                       << "New Definition: ";
                                  getline(cin, tmp);
                                  if (tmp > "")
                                    n.definition = tmp;
                                  break;
                                case 4 : 
                                  cls(h_);
                                  cout << "Old Return Type: " << n.returnType << endl
                                       << "New Return Type: ";
                                  cin >> n.returnType;
                                  break;
                                case 5 : 
                                  cls(h_);
                                  cout << "Old Priority: " << n.priority << endl
                                       << "New Priority: ";
                                  cin >> n.priority;
                                  break;
                                case 6 : 
                                  do {
                                    cls(h_);
                                    cout << "Model Count: " << n.modelCount << endl
                                         << "Models: "                      << endl;
                                    for (int i = 0; i < n.modelCount; i ++)
                                      cout << "    " << n.models[i].match << endl;
                                    cout << endl
                                         << "0 - Done Editing Models" << endl
                                         << "1 - Edit Model" << endl
                                         << "2 - Add Model" << endl
                                         << "3 - Remove Model" << endl
                                         << "4 - Swap Model Order" << endl
                                         << "5 - Organize Models" << endl << endl
                                         << ": ";
                                    cin >> e;
                                    getline(cin, tmp);
                                    switch (e)
                                    {
                                      case 0 : 
                                        break;
                                      case 1 : 
                                        do {
                                          cls(h_);
                                          cout << "Model Count: " << n.models.size() << endl
                                               << "Models: "                         << endl;
                                          for (size_t i = 0; i < n.models.size(); i ++)
                                            cout << "    [" << i + 1 << "] " << n.models[i].match << endl;
                                          cout << endl
                                               << "0 - Done Editing Models" << endl
                                               << "X - Edit Model [X]" << endl << endl
                                               << ": ";
                                          cin >> f;
                                          getline(cin, tmp);
                                          if (f > 0 && f <= (int) n.models.size()) {
                                            Model& p = n.models[f - 1];
                                            do {
                                              cls(h_);
                                              p.dump();
                                              cout << "0 - Done Editing Model [" << f << "]" << endl
                                                   << "1 - Change Match" << endl
                                                   << "2 - Change Priority" << endl
                                                   << "3 - Change Command Type" << endl
                                                   << "4 - Change Question Type" << endl
                                                   << "5 - Change Question" << endl << endl
                                                   << ": ";
                                              cin >> g;
                                              getline(cin, tmp);
                                              switch (g)
                                              {
                                                case 0 : 
                                                  break;
                                                case 1 : 
                                                  cls(h_);
                                                  cout << "Old Match: " << p.match << endl
                                                       << "New Match: ";
                                                  getline(cin, tmp);
                                                  if (tmp > "")
                                                    p.match = uCase(tmp);
                                                  break;
                                                case 2 : 
                                                  cls(h_);
                                                  cout << "Old Priority: " << p.priority << endl
                                                       << "New Priority: ";
                                                  cin >> p.priority;
                                                  break;
                                                case 3 : 
                                                  cls(h_);
                                                  cout << "Old Command Type: " << p.commandType << endl
                                                       << "New Command Type: ";
                                                  cin >> p.commandType;
                                                  break;
                                                case 4 : 
                                                  cls(h_);
                                                  cout << "Old Question Type: " << p.questionType << endl
                                                       << "New Question Type: ";
                                                  cin >> p.questionType;
                                                  break;
                                                case 5 : 
                                                  cls(h_);
                                                  cout << "Old Question: " << p.question << endl
                                                       << "New Question: ";
                                                  cin >> p.question;
                                                  break;
                                              }
                                            } while (g > 0);
                                          }
                                        } while (f > 0);
                                        break;
                                      case 2 : 
                                        do {
                                          cls(h_);
                                          cout << "Model Count: " << n.models.size() << endl
                                               << "Models: "                         << endl;
                                          for (size_t i = 0; i < n.models.size(); i ++)
                                            cout << "    " << n.models[i].match << endl;
                                          cout << endl
                                               << "0 - Done Adding Models" << endl
                                               << "1 - Add a Model" << endl << endl
                                               << ": ";
                                          cin >> f;
                                          getline(cin, tmp);
                                          switch (f)
                                          {
                                            case 0 : 
                                              break;
                                            case 1 : 
                                              Model x;
                                              bool isnew = true;
                                              do {
                                                cls(h_);
                                                cout << "Match: ";
                                                getline(cin, tmp);
                                                if (tmp > "") {
                                                  for (size_t i = 0; i < n.models.size(); i ++)
                                                    if (n.models[i].match == tmp)
                                                      isnew = false;
                                                  if (isnew)
                                                    x.match = uCase(tmp);
                                                }
                                              } while (!isnew);
                                              cout << "Priority: ";
                                              cin >> x.priority;
                                              getline(cin, tmp);
                                              cout << "Command Type: ";
                                              cin >> x.commandType;
                                              getline(cin, tmp);
                                              cout << "Question Type: ";
                                              cin >> x.questionType;
                                              getline(cin, tmp);
                                              cout << "Question: ";
                                              cin >> x.question;
                                              getline(cin, tmp);
                                              n.models.push_back(x);
                                              n.modelCount ++;
                                              break;
                                          }
                                        } while (f > 0);
                                        break;
                                      case 3 : 
                                        do {
                                          cls(h_);
                                          cout << "Model Count: " << n.models.size() << endl
                                               << "Models: "                         << endl;
                                          for (size_t i = 0; i < n.models.size(); i ++)
                                            cout << "    [" << i + 1 << "] " << n.models[i].match << endl;
                                          cout << endl
                                               << "0 - Done Removing Models" << endl
                                               << "X - Remove Model [X]" << endl << endl
                                               << ": ";
                                          cin >> f;
                                          getline(cin, tmp);
                                          if (f > 0 && f <= (int) n.models.size()) {
                                            n.models.erase(n.models.begin() + f - 1);
                                            n.modelCount --;
                                          }
                                        } while (f > 0);
                                        break;
                                      case 4 : 
                                        do {
                                          cls(h_);
                                          cout << "Model Count: " << n.models.size() << endl
                                               << "Models: "                               << endl;
                                          for (size_t i = 0; i < n.models.size(); i ++)
                                            cout << "    [" << i + 1 << "] " << n.models[i].match << endl;
                                          cout << endl
                                               << "0 - Done Moving Models" << endl
                                               << "X - Move Model [X]" << endl << endl
                                               << ": ";
                                          cin >> f;
                                          getline(cin, tmp);
                                          if (f > 0 && f <= (int) n.models.size()) {
                                            cls(h_);
                                            cout << "Model Count: " << n.models.size() << endl
                                                 << "Models: "                         << endl;
                                            for (size_t i = 0; i < (int) n.models.size(); i ++)
                                              cout << "    " << n.models[i].match << endl;
                                            cout << endl
                                                 << "0 - Cancel Move" << endl
                                                 << "1 - Move to Top" << endl
                                                 << "2 - Move to Bottom" << endl
                                                 << "3 - Move to a Position" << endl
                                                 << "4 - Swap with a Position" << endl << endl
                                                 << ": ";
                                            cin >> g;
                                            getline(cin, tmp);
                                            switch (g)
                                            {
                                              case 0 : 
                                                break;
                                              case 1 : 
                                                n.models.insert(n.models.begin(), n.models[f - 1]);
                                                n.models.erase(n.models.begin() + f);
                                                break;
                                              case 2 : 
                                                n.models.insert(n.models.end(), n.models[f - 1]);
                                                n.models.erase(n.models.begin() + f - 1);
                                                break;
                                              case 3 : 
                                                cls(h_);
                                                cout << "Model Count: " << n.models.size() << endl
                                                     << "Models: "                         << endl;
                                                for (size_t i = 0; i < (int) n.models.size(); i ++)
                                                  cout << "    [" << i + 1 << "] " << n.models[i].match << endl;
                                                cout << endl
                                                     << "0 - Cancel Move" << endl
                                                     << "X - Move to Position [X]" << endl << endl
                                                     << ": ";
                                                cin >> h;
                                                getline(cin, tmp);
                                                if (h > 0 && h <= (int) n.models.size() && h != f) {
                                                  n.models.insert(n.models.begin() + h - 1, n.models[f - 1]);
                                                  if (h < f)
                                                    n.models.erase(n.models.begin() + f);
                                                  else
                                                    n.models.erase(n.models.begin() + f - 1);
                                                }
                                                break;
                                              case 4 : 
                                                cls(h_);
                                                cout << "Model Count: " << n.models.size() << endl
                                                     << "Models: "                         << endl;
                                                for (size_t i = 0; i < (int) n.models.size(); i ++)
                                                  cout << "    [" << i + 1 << "] " << n.models[i].match << endl;
                                                cout << endl
                                                     << "0 - Cancel Swap" << endl
                                                     << "X - Swap with Position [X]" << endl << endl
                                                     << ": ";
                                                cin >> h;
                                                getline(cin, tmp);
                                                if (h > 0 && h <= (int) n.models.size() && h != f)
                                                  swap(n.models[f - 1], n.models[h - 1]);
                                                break;
                                            }
                                          }
                                        } while (f > 0);
                                        break;
                                      case 5 : 
                                        do {
                                          cls(h_);
                                          cout << "Model Count: " << n.models.size() << endl
                                               << "Models: "                         << endl;
                                          for (size_t i = 0; i < (int) n.models.size(); i ++)
                                            cout << "    " << n.models[i].match << endl;
                                          cout << endl
                                               << "0 - Done Organizing" << endl
                                               << "1 - Organize Alphabetically" << endl
                                               << "2 - Organize Alphabetically (Reverse)" << endl
                                               << "3 - Organize by Priority" << endl
                                               << "4 - Organize by Priority (Reverse)" << endl
                                               << "5 - Organize by Command Type" << endl
                                               << "6 - Organize by Command Type (Reverse)" << endl
                                               << ": ";
                                          cin >> f;
                                          getline(cin, tmp);
                                          switch (f)
                                          {
                                            case 0 : 
                                              break;
                                            case 1 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++)
                                                  if (n.models[j].match > n.models[i].match)
                                                    swap(n.models[j], n.models[i]);
                                              break;
                                            case 2 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++)
                                                  if (n.models[j].match < n.models[i].match)
                                                    swap(n.models[j], n.models[i]);
                                              break;
                                            case 3 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++)
                                                  if (n.models[j].priority > n.models[i].priority)
                                                    swap(n.models[j], n.models[i]);
                                              break;
                                            case 4 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++)
                                                  if (n.models[j].priority < n.models[i].priority)
                                                    swap(n.models[j], n.models[i]);
                                              break;
                                            case 5 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++) {
                                                  if (n.models[j].commandType > n.models[i].commandType)
                                                    swap(n.models[j], n.models[i]);
                                                  else if (n.models[j].commandType == n.models[i].commandType)
                                                    if (n.models[j].match > n.models[i].match)
                                                      swap(n.models[j], n.models[i]);
                                                }
                                              break;
                                            case 6 : 
                                              for (int i = 0; i < n.modelCount; i ++)
                                                for (int j = 0; j < n.modelCount; j ++) {
                                                  if (n.models[j].commandType < n.models[i].commandType)
                                                    swap(n.models[j], n.models[i]);
                                                  else if (n.models[j].commandType == n.models[i].commandType)
                                                    if (n.models[j].match < n.models[i].match)
                                                      swap(n.models[j], n.models[i]);
                                                }
                                              break;
                                          }
                                        } while (f > 0);
                                        break;
                                    }
                                  } while (e > 0);
                                  break;
                                case 7 : 
                                  cls(h_);
                                  cout << "Old Output: " << n.output << endl
                                       << "New Output: ";
                                  getline(cin, tmp);
                                  if (tmp > "")
                                    n.output = tmp;
                                  break;
                                case 8 : 
                                  cls(h_);
                                  cout << "Old Risk: " << n.risk << endl
                                       << "New Risk: ";
                                  cin >> n.risk;
                                  break;
                              }
                            } while (d > 0);
                          }
                        } while (c > 0);
                        break;
                      case 2 : 
                        do {
                          cls(h_);
                          cout << "Command Count: " << m.commandCount << endl
                               << "Commands: "                        << endl;
                          for (int i = 0; i < m.commandCount; i ++)
                            cout << "    " << m.commands[i].name << endl;
                          cout << endl
                               << "0 - Done Adding Commands" << endl
                               << "1 - Add a Command" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          switch (c)
                          {
                            case 0 : 
                              break;
                            case 1 : 
                              Command x;
                              bool isnew = true;
                              do {
                                cls(h_);
                                cout << "Name: ";
                                getline(cin, tmp);
                                if (tmp > "") {
                                  for (int i = 0; i < m.commandCount; i ++)
                                    if (m.commands[i].name == tmp)
                                      isnew = false;
                                  if (isnew)
                                    x.name = tmp;
                                }
                              } while (!isnew);
                              cout << "Description: ";
                              getline(cin, x.description);
                              cout << "Definition: ";
                              getline(cin, x.definition);
                              cout << "Return Type: ";
                              cin >> x.returnType;
                              getline(cin, tmp);
                              x.module = m.name;
                              x.modulePriority = m.priority;
                              cout << "Priority: ";
                              cin >> x.priority;
                              getline(cin, tmp);
                              x.modelCount = 0;
                              cout << "Output: ";
                              getline(cin, x.output);
                              cout << "Risk: ";
                              cin >> x.risk;
                              getline(cin, tmp);
                              m.commands.push_back(x);
                              m.commandCount ++;
                              break;
                          }
                        } while (c > 0);
                        break;
                      case 3 : 
                        do {
                          cls(h_);
                          cout << "Command Count: " << m.commandCount << endl
                               << "Commands: "                        << endl;
                          for (int i = 0; i < m.commandCount; i ++)
                            cout << "    [" << i + 1 << "] " << m.commands[i].name << endl;
                          cout << endl
                               << "0 - Done Removing Commands" << endl
                               << "X - Remove Commands [X]" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          if (c > 0 && c <= m.commandCount) {
                            m.commands.erase(m.commands.begin() + c - 1);
                            m.commandCount --;
                          }
                        } while (c > 0);
                        break;
                      case 4 : 
                        do {
                          cls(h_);
                          cout << "Command Count: " << m.commandCount << endl
                               << "Commands: "                          << endl;
                          for (int i = 0; i < m.commandCount; i ++)
                            cout << "    [" << i + 1 << "] " << m.commands[i].name << endl;
                          cout << endl
                               << "0 - Done Moving Commands" << endl
                               << "X - Move Command [X]" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          if (c > 0 && c <= m.commandCount) {
                            cls(h_);
                            cout << "Command Count: " << m.commandCount << endl
                                 << "Commands: "                        << endl;
                            for (int i = 0; i < m.commandCount; i ++)
                              cout << "    " << m.commands[i].name << endl;
                            cout << endl
                                 << "0 - Cancel Move" << endl
                                 << "1 - Move to Top" << endl
                                 << "2 - Move to Bottom" << endl
                                 << "3 - Move to a Position" << endl
                                 << "4 - Swap with a Position" << endl << endl
                                 << ": ";
                            cin >> d;
                            getline(cin, tmp);
                            switch (d)
                            {
                              case 0 : 
                                break;
                              case 1 : 
                                m.commands.insert(m.commands.begin(), m.commands[c - 1]);
                                m.commands.erase(m.commands.begin() + c);
                                break;
                              case 2 :
                                m.commands.insert(m.commands.end(), m.commands[c - 1]);
                                m.commands.erase(m.commands.begin() + c - 1);
                                break;
                              case 3 : 
                                cls(h_);
                                cout << "Command Count: " << m.commandCount << endl
                                     << "Commands: "                         << endl;
                                for (int i = 0; i < m.commandCount; i ++)
                                  cout << "    [" << i + 1 << "] " << m.commands[i].name << endl;
                                cout << endl
                                     << "0 - Cancel Move" << endl
                                     << "X - Move to Position [X]" << endl << endl
                                     << ": ";
                                cin >> e;
                                getline(cin, tmp);
                                if (e > 0 && e <= m.commandCount && e != c) {
                                  m.commands.insert(m.commands.begin() + e - 1, m.commands[c - 1]);
                                  if (e < c)
                                    m.commands.erase(m.commands.begin() + c);
                                  else
                                    m.commands.erase(m.commands.begin() + c - 1);
                                }
                                break;
                              case 4 : 
                                cls(h_);
                                cout << "Command Count: " << m.commandCount << endl
                                     << "Commands: "                        << endl;
                                for (int i = 0; i < m.commandCount; i ++)
                                  cout << "    [" << i + 1 << "] " << m.commands[i].name << endl;
                                cout << endl
                                     << "0 - Cancel Swap" << endl
                                     << "X - Swap with Position [X]" << endl << endl
                                     << ": ";
                                cin >> e;
                                getline(cin, tmp);
                                if (e > 0 && e <= m.commandCount && e != c)
                                  swap(m.commands[c - 1], m.commands[e - 1]);
                                break;
                            }
                          }
                        } while (c > 0);
                        break;
                      case 5 :                   
                        do {
                          cls(h_);
                          cout << "Command Count: " << m.commandCount << endl
                               << "Commands: "                        << endl;
                          for (int i = 0; i < m.commandCount; i ++)
                            cout << "    " << m.commands[i].name << endl;
                          cout << endl
                               << "0 - Done Organizing Commands" << endl
                               << "1 - Organize Alphabetically" << endl
                               << "2 - Organize Alphabetically (Reverse)" << endl
                               << "3 - Organize by Return Type" << endl
                               << "4 - Organize by Return Type (Reverse)" << endl
                               << "5 - Organize by Priority" << endl
                               << "6 - Organize by Priority (Reverse)" << endl
                               << "7 - Organize by Risk" << endl
                               << "8 - Organize by Risk (Reverse)" << endl << endl
                               << ": ";
                          cin >> c;
                          getline(cin, tmp);
                          switch (c)
                          {
                            case 0 : 
                              break;
                            case 1 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].name > m.commands[i].name)
                                    swap(m.commands[j], m.commands[i]);
                              break;
                            case 2 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].name < m.commands[i].name)
                                    swap(m.commands[j], m.commands[i]);
                              break;
                            case 3 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].returnType > m.commands[i].returnType)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].returnType == m.commands[i].returnType)
                                    if (m.commands[j].name > m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                            case 4 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].returnType < m.commands[i].returnType)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].returnType == m.commands[i].returnType)
                                    if (m.commands[j].name < m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                            case 5 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].priority > m.commands[i].priority)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].priority == m.commands[i].priority)
                                    if (m.commands[j].name > m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                            case 6 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].priority < m.commands[i].priority)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].priority == m.commands[i].priority)
                                    if (m.commands[j].name < m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                            case 7 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].risk > m.commands[i].risk)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].risk == m.commands[i].risk)
                                    if (m.commands[j].name > m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                            case 8 : 
                              for (int i = 0; i < m.commandCount; i ++)
                                for (int j = 0; j < m.commandCount; j ++)
                                  if (m.commands[j].risk < m.commands[i].risk)
                                    swap(m.commands[j], m.commands[i]);
                                  else if (m.commands[j].risk == m.commands[i].risk)
                                    if (m.commands[j].name < m.commands[i].name)
                                      swap(m.commands[j], m.commands[i]);
                              break;
                          }
                        } while (c > 0);
                        break;
                    }
                  } while (b > 0);
                  break;
                case 6 : 
                  cls(h_);              
                  cout << "This will organize everything in the module." << endl << endl
                       << "0 - Done Organizing Module" << endl
                       << "1 - Organize Alphabetically" << endl
                       << "2 - Organize Alphabetically (Reverse)" << endl
                       << "3 - Organize by Priority" << endl
                       << "4 - Organize by Priority (Reverse)" << endl << endl
                       << ": ";
                  cin >> b;
                  getline(cin, tmp);
                  switch (b)
                  {
                    case 0 : 
                      break;
                    case 1 : 
                      for (size_t i = 0; i < m.dependencies.size(); i ++)
                        for (size_t j = 0; j < m.dependencies.size(); j ++)
                          if (m.dependencies[j] > m.dependencies[i])
                            swap(m.dependencies[j], m.dependencies[i]);
                      for (int i = 0; i < m.commandCount; i ++)
                        for (int j = 0; j < m.commandCount; j ++)
                          if (m.commands[j].name > m.commands[i].name)
                            swap(m.commands[j], m.commands[i]);
                      for (int i = 0; i < m.commandCount; i ++) {
                        Command& n = m.commands[i];
                        for (int i = 0; i < n.modelCount; i ++)
                          for (int j = 0; j < n.modelCount; j ++)
                            if (n.models[j].match > n.models[i].match)
                              swap(n.models[j], n.models[i]);
                      }
                      break;
                    case 2 : 
                      for (size_t i = 0; i < m.dependencies.size(); i ++)
                        for (size_t j = 0; j < m.dependencies.size(); j ++)
                          if (m.dependencies[j] < m.dependencies[i])
                            swap(m.dependencies[j], m.dependencies[i]);
                      for (int i = 0; i < m.commandCount; i ++)
                        for (int j = 0; j < m.commandCount; j ++)
                          if (m.commands[j].name < m.commands[i].name)
                            swap(m.commands[j], m.commands[i]);
                      for (int i = 0; i < m.commandCount; i ++) {
                        Command& n = m.commands[i];
                        for (int i = 0; i < n.modelCount; i ++)
                          for (int j = 0; j < n.modelCount; j ++)
                            if (n.models[j].match < n.models[i].match)
                              swap(n.models[j], n.models[i]);
                      }
                      break;
                    case 3 : 
                      for (size_t i = 0; i < m.dependencies.size(); i ++)
                        for (size_t j = 0; j < m.dependencies.size(); j ++)
                          if (m.dependencies[j] > m.dependencies[i])
                            swap(m.dependencies[j], m.dependencies[i]);
                      for (int i = 0; i < m.commandCount; i ++)
                        for (int j = 0; j < m.commandCount; j ++)
                          if (m.commands[j].priority > m.commands[i].priority)
                            swap(m.commands[j], m.commands[i]);
                          else if (m.commands[j].priority == m.commands[i].priority)
                            if (m.commands[j].name > m.commands[i].name)
                              swap(m.commands[j], m.commands[i]);
                      for (int i = 0; i < m.commandCount; i ++) {
                        Command& n = m.commands[i];
                        for (int i = 0; i < n.modelCount; i ++)
                          for (int j = 0; j < n.modelCount; j ++)
                            if (n.models[j].priority > n.models[i].priority)
                              swap(n.models[j], n.models[i]);
                            else if (n.models[j].priority == n.models[i].priority)
                              if (n.models[j].match > n.models[i].match)
                                swap(n.models[j], n.models[i]);
                      }
                      break;
                    case 4 : 
                      for (size_t i = 0; i < m.dependencies.size(); i ++)
                        for (size_t j = 0; j < m.dependencies.size(); j ++)
                          if (m.dependencies[j] < m.dependencies[i])
                            swap(m.dependencies[j], m.dependencies[i]);
                      for (int i = 0; i < m.commandCount; i ++)
                        for (int j = 0; j < m.commandCount; j ++)
                          if (m.commands[j].priority < m.commands[i].priority)
                            swap(m.commands[j], m.commands[i]);
                          else if (m.commands[j].priority == m.commands[i].priority)
                            if (m.commands[j].name < m.commands[i].name)
                              swap(m.commands[j], m.commands[i]);
                      for (int i = 0; i < m.commandCount; i ++) {
                        Command& n = m.commands[i];
                        for (int i = 0; i < n.modelCount; i ++)
                          for (int j = 0; j < n.modelCount; j ++)
                            if (n.models[j].priority < n.models[i].priority)
                              swap(n.models[j], n.models[i]);
                            else if (n.models[j].priority == n.models[i].priority)
                              if (n.models[j].match < n.models[i].match)
                                swap(n.models[j], n.models[i]);
                      }
                      break;
                  }
                  break;
                case 7 : 
                  if (moduleUser[a1 - 1] == "") {
                    addToDla(m, loc);
                    cls(h_);
                    cout << "This module has been added to the system." << endl;
                    system("PAUSE");
                  }
                  break;
                case 8 : 
                  if (moduleUser[a1 - 1] == "") {
                    cls(h_);
                    cout << "Are you sure you want to remove this module from the system?" << endl
                         << "By doing so, all users on this system that had included the modules will no longer have access to them. Also all user-specific modules of the same name will not be deleted but will be removed from the user's access" << endl
                         << "0 - Do not remove the module" << endl
                         << "1 - I understand, remove the module" << endl
                         << ": ";
                    cin >> b;
                    getline(cin, tmp);
                    switch (b) {
                      case 0:
                        break;
                      case 1:
                        removeFromDla(m, loc);
                        cls(h_);
                        cout << "This module has been removed from the system." << endl
                             << "This module has been removed from all user accounts including user-specific modules of the same name." << endl;
                        system("PAUSE");
                        break;
                    }
                  }
                  break;
                case 9:
                  if (moduleUser[a1 - 1] == "") {
                    do {
                      cls(h_);
                      cout << "Which user would you like to add this module to?" << endl
                        << "0 - Cancel" << endl
                        << "1 - All Users" << endl;
                      loadLists(loc, modules, moduleUser, users);
                      for (size_t i = 0; i < users.size(); i++)
                        cout << i + 2 << " - " << users[i] << endl;
                      cout << endl << ": ";
                      cin >> b;
                      getline(cin, tmp);
                      switch (b) {
                        case 0:
                          break;
                        case 1:
                          for (size_t i = 0; i < users.size(); i++)
                            addToUser(m, loc, users[i]);
                          cls(h_);
                          cout << "This module has been added to all users." << endl;
                          system("PAUSE");
                          break;
                        default:
                          if (b > 1 && b < (int)users.size() + 2) {
                            addToUser(m, loc, users[b - 2]);
                            cls(h_);
                            cout << "This module has been added to the user " << users[b - 2] << "." << endl;
                            system("PAUSE");
                          }
                          break;
                      }
                    } while (b > 0);
                  }
                  else {
                    addToUser(m, loc, moduleUser[a1 - 1]);
                    addUserModule(m, loc, moduleUser[a1 - 1]);
                    cls(h_);
                    cout << "This module has been added to the user " << moduleUser[a1 - 1] << "." << endl;
                    system("PAUSE");
                  }
                  break;
                case 10:
                  if (moduleUser[a1 - 1] == "") {
                    do {
                      cls(h_);
                      cout << "Which user would you like to remove this module from?" << endl
                        << "0 - Cancel" << endl
                        << "1 - All Users" << endl;
                      loadLists(loc, modules, moduleUser, users);
                      for (size_t i = 0; i < users.size(); i++)
                        cout << i + 2 << " - " << users[i] << endl;
                      cout << endl << ": ";
                      cin >> b;
                      getline(cin, tmp);
                      switch (b) {
                        case 0:
                          break;
                        case 1:
                          for (size_t i = 0; i < users.size(); i++)
                            removeFromUser(m, loc, users[i]);
                          cls(h_);
                          cout << "This module has been removed from all users." << endl;
                          system("PAUSE");
                          break;
                        default:
                          if (b > 1 && b < (int)users.size() + 2) {
                            removeFromUser(m, loc, users[b - 2]);
                            cls(h_);
                            cout << "This module has been removed from the user " << users[b - 2] << "." << endl;
                            system("PAUSE");
                          }
                          break;
                      }
                    } while (b > 0);
                  }
                  else {
                    removeFromUser(m, loc, moduleUser[a1 - 1]);
                    removeUserModule(m, loc, moduleUser[a1 - 1]);
                    cls(h_);
                    cout << "This module has been removed from the user " << moduleUser[a1 - 1] << "." << endl;
                    system("PAUSE");
                  }
                  break;
                case 11:
                  if (modules[a1 - 1].find("user/") == string::npos) {
                    do {
                      loadLists(loc, modules, moduleUser, users);
                      string tmpStr = "";
                      cls(h_);
                      cout << "Select a user to add the private module to." << endl;
                      for (size_t i = 0; i < users.size(); i++)
                        cout << "[" << i + 1 << "] - " << users[i] << endl;
                      cout << endl
                        << "0 - Return" << endl
                        << "X - Add to User [X]" << endl
                        << ": ";
                      cin >> b;
                      getline(cin, tmpStr);
                      switch (b) {
                        case 0:
                          break;
                        default:
                          if (b > 0 && b < (int)users.size() + 1) {
                            if (!fileExists(loc + "data/user/" + users[b - 1] + "/module/" + m.name + ".module")) {
                              copyFile(loc + "data/module/" + lCase(m.name) + ".module", loc + "data/user/" + users[b - 1] + "/module/" + lCase(m.name) + ".module");
                              addToUser(m, loc, users[b - 1]);
                              addUserModule(m, loc, users[b - 1]);
                              cls(h_);
                              cout << "An instance of this module has been copied to " << users[b - 1] << "." << endl;
                              system("PAUSE");
                            }
                            else {
                              cls(h_);
                              cout << "This user already has an instance of this module." << endl;
                              system("PAUSE");
                            }
                          }
                          break;
                      }
                    } while (b > 0);
                  }
                  break;
              }
            } while (a > 0);
          }
        } while (a1 > 0);
        break;
      case 2 : 
        do {
          loadLists(loc, modules, moduleUser, users);
          cls(h_);
          cout << "Module Count: " << modules.size() << endl
               << "Modules" << endl;
          for (size_t i = 0; i < modules.size(); i ++)
            cout << "    " << modules[i] << endl;
          cout << endl
               << "0 - Done Adding Modules" << endl
               << "1 - Add a Module" << endl << endl
               << ": ";
          cin >> a1;
          getline(cin, tmp);
          switch (a1)
          {
            case 0 : 
              break;
            case 1 : 
              Module x;
              bool isnew = true;
              do {
                cls(h_);
                cout << "Name: ";
                getline(cin, tmp);
                if (tmp > "") {
                  for (size_t i = 0; i < modules.size(); i ++)
                    if (modules[i] == tmp)
                      isnew = false;
                  if (isnew)
                    x.name = tmp;
                }
              } while (!isnew);
              cout << "Description: ";
              getline(cin, x.description);
              cout << "Priority: ";
              cin >> x.priority;
              getline(cin, tmp);
              x.commandCount = 0;
              string modfile = loc + "data/module/" + x.name;
              makeFunctions(x, loc);
              makeCpp(x, loc);
              makeH(x, loc);
              saveModule(x, loc, "", modfile);
              break;
          }
        } while (a1 > 0);
        break;
      case 3 : 
        do {
          loadLists(loc, modules, moduleUser, users);
          cls(h_);
          cout << "Proceed with caution!!!" << endl << endl;
          cout << "Module Count: " << modules.size() << endl
               << "Modules: "                        << endl;
          for (size_t i = 0; i < modules.size(); i ++)
            cout << "    [" << i + 1 << "] " << modules[i] << endl;
          cout << endl
               << "0 - Done Removing Modules" << endl
               << "X - Remove Module [X]" << endl << endl
               << ": ";
          cin >> a1;
          getline(cin, tmp);
          if (a1 > 0 && a1 <= (int) modules.size()) {
            string modfile = loc + "data/module/" + modules[a1 - 1] + ".module";
            Module t (modfile);
            if (moduleUser[a1 - 1] > "") {
              backupModule(t, loc, loc + "data/user/" + moduleUser[a1 - 1]);
              deleteFile(modfile);
              removeUserModule(t, loc, moduleUser[a1 - 1]);
            }
            else {
              backupModule(t, loc, loc + "data");
              deleteFile(modfile);
              modfile = loc + "data/module/" + modules[a1 - 1] + ".functions";
              deleteFile(modfile);
              modfile = loc + "source/module/" + lCase(t.name) + ".cpp";
              deleteFile(modfile);
              modfile = loc + "source/module/" + lCase(t.name) + ".h";
              deleteFile(modfile);
              removeFromDla(t, loc);
            }
            cls(h_);
            cout << "A final backup has been created in 'backup/module'. To restore a deleted module return a backup file to 'data/module'." << endl;
            system("PAUSE");
          }
        } while (a1 > 0);
        break;
    }
  } while (a0 > 0);
  return 0;
}



void loadLists(string loc, vector<string>& modules, vector<string>& moduleUser, vector<string>& users) {
  modules.clear();
  moduleUser.clear();
  users.clear();
  vector<string> tmpModules;
  readDirectory(loc + "data/module/", ".module", modules);
  for (size_t i = 0; i < modules.size(); i++)
    moduleUser.push_back("");
  loadFileS(loc + "data/users", users);
  for (size_t i = 0; i < users.size(); i++) {
    tmpModules.clear();
    readDirectory(loc + "data/user/" + users[i] + "/module/", ".module", tmpModules);
    for (size_t j = 0; j < tmpModules.size(); j++) {
      modules.push_back("../user/" + users[i] + "/module/" + tmpModules[j]);
      moduleUser.push_back(users[i]);
    }
  }
}



void backupModule (Module m, string loc, string modloc)
{
  string modfile = "";
  string newfile = "";

  string newdir = modloc + "/backup/module/" + lCase(m.name);
  makeFolder(newdir);
  newdir +=  "/" + str((int) time(0));
  makeFolder(newdir);

  modfile = modloc + "/module/" + lCase(m.name) + ".module";
  newfile = newdir + "/" + lCase(m.name) + ".module";
  if (fileExists(modfile))
    copyFile(modfile, newfile);

  modfile = loc + "data/module/" + lCase(m.name) + ".functions";
  newfile = newdir + "/" + lCase(m.name) + ".functions";
  if (fileExists(modfile))
    copyFile(modfile, newfile);

  modfile = loc + "source/module/" + lCase(m.name) + ".cpp";
  newfile = newdir + "/" + lCase(m.name) + ".cpp";
  if (fileExists(modfile))
    copyFile(modfile, newfile);

  modfile = loc + "source/module/" + lCase(m.name) + ".h";
  newfile = newdir + "/" + lCase(m.name) + ".h";
  if (fileExists(modfile))
    copyFile(modfile, newfile);
}


void saveModule (Module m, string loc, string user, string modloc)
{
  if (modloc.find("..") > 0)
    backupModule(m, loc, loc + "data/user/" + user);
  else
    backupModule(m, loc, loc + "data");

  string modfile = modloc + ".module";

  fstream moduleFile;
  moduleFile.open(modfile.c_str(), fstream::out);
  moduleFile << uCase(m.name) << endl
             << m.description << endl
             << m.priority << endl;
  string depstr = "";
  for (size_t i = 0; i < m.dependencies.size(); i ++) {
    if (depstr > "")
      depstr += ",";
    depstr += uCase(m.dependencies[i]);
  }
  moduleFile << depstr << endl;
  for (int i = 0; i < m.commandCount; i ++) {
    Command& n = m.commands[i];
    moduleFile << i + 1 << endl
               << n.name << endl
               << n.description << endl
               << n.definition << endl
               << n.returnType << endl
               << n.module << endl
               << n.modulePriority << endl
               << n.priority << endl;
    for (int j = 0; j < n.modelCount; j ++) {
      Model& p = n.models[j];
      moduleFile << j + 1 << endl
                 << p.match << endl
                 << p.priority << endl
                 << p.commandType << endl
                 << p.questionType << endl
                 << p.question << endl;
    }
    moduleFile << "0" << endl
               << n.output << endl
               << n.risk << endl;
  }
  moduleFile << "0";
  makeFunctions(m, loc);
}


void makeFunctions (Module m, string loc)
{
  fstream fsi;
  fstream fso;
  fsi.open(loc + "source/module/" + lCase(m.name) + ".h", fstream::in);
  fso.open(loc + "data/module/" + lCase(m.name) + ".functions", fstream::out);
  string line = "";

  bool reading = false;
  while (getline(fsi, line)) {
    if (line == "  namespace PRIVATE")
      reading = false;
    if (reading) {
      if (line != "" && line != "{") {
        string name = "";
        bool hit = false;
        int j = 0;
        for (size_t i = 0; i < line.length(); i++) {
          if (hit == true && name == "") {
            if (line.substr(i, 1) == " ") {
              do {
                i++;
              } while (line.substr(i, 1) == " ");
              name = line.substr(i);
              do {
                j++;
              } while (name.substr(j, 1) != " " && name.substr(j, 1) != "(");
              name = name.substr(0, j);
            }
          }
          if (line.substr(i, 1) != " ")
            hit = true;
        }

        fso << "CommandPtrs_[\"" << uCase(m.name) << "::" << name << "\"] = &" << uCase(m.name) << "::" << name << ";" << endl;
      }
    }
    if (line == "namespace " + uCase(m.name))
      reading = true;
  }

  fsi.close();
  fso.close();
}
void makeCpp (Module m, string loc)
{
  fstream fs;
  string openfile = loc + "source/module/" + m.name + ".cpp";
  fs.open(openfile.c_str(), fstream::out);

  fs << "////////////////////////////////////////////////////////////////////////////////" << endl
     << "//File:   " << m.name << ".cpp" << endl
     << "//Dir:    source/module/" << endl
     << "//Date:   YYYY-MM-DD" << endl
     << "//Author: Zachary Gill" << endl
     << "//Implementation of " << uCase(m.name) << " module" << endl
     << "////////////////////////////////////////////////////////////////////////////////" << endl << endl << endl
     << "//constants" << endl
     << "#include \"../resource/const.h\"" << endl << endl << endl
     << "//standard includes" << endl << endl << endl
     << "//includes" << endl
     << "#include \"" << m.name << ".h\"" << endl << endl << endl
     << "//namespaces" << endl
     << "using namespace std;" << endl << endl << endl
     << "//functions" << endl << endl
     << "string " << uCase(m.name) << "::main ()" << endl
     << "{" << endl
     << "  return \"\";" << endl
     << "}" << endl << endl;

  fs.close();
}
void makeH (Module m, string loc)
{
  fstream fs;
  string openfile = loc + "source/module/" + m.name + ".h";
  fs.open(openfile.c_str(), fstream::out);

  fs << "////////////////////////////////////////////////////////////////////////////////" << endl
     << "//File:   " << m.name << ".h" << endl
     << "//Dir:    source/module/" << endl
     << "//Date:   YYYY-MM-DD" << endl
     << "//Author: Zachary Gill" << endl
     << "//Interface of " << uCase(m.name) << " module" << endl
     << "////////////////////////////////////////////////////////////////////////////////" << endl << endl << endl
     << "#ifndef _JARVIS_SM_" << uCase(m.name) << "_H_" << endl
     << "#define _JARVIS_SM_" << uCase(m.name) << "_H_" << endl << endl << endl
     << "//constants" << endl
     << "#include \"../resource/const.h\"" << endl << endl << endl
     << "//standard includes" << endl << endl << endl
     << "//includes" << endl << endl << endl
     << "//namespace defintions" << endl
     << "namespace " << uCase(m.name) << endl
     << "{" << endl
     << "  std::string main ();" << endl << endl
     << "  namespace PRIVATE" << endl
     << "  {" << endl << endl
     << "  } ;" << endl
     << "} ;" << endl << endl << endl
     << "//global variable definitions" << endl << endl << endl
     << "#endif";


  fs.close();
}


void addToDla(Module m, string loc)
{
  removeFromDla(m, loc);

  //add name to module file
  vector<string> modules;
  loadFileS(loc + "data/modules", modules);
  bool has = false;
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] == lCase(m.name))
      has = true;
  }
  if (has == false)
    modules.push_back(lCase(m.name));
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "modules";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs1 << modules[i] << endl;
  fs1.close();

  //add name to module/ptrs file
  modules.clear();
  loadFileS(loc + "data/module/ptrs", modules);
  has = false;
  string ptrStr = "#include \"" + lCase(m.name) + ".functions\"";
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] == ptrStr)
      has = true;
  }
  modules.push_back(ptrStr);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs2;
  openfile = loc + "data/module/ptrs";
  fs2.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs2 << modules[i] << endl;
  fs2.close();

  //add to resource/modules file
  modules.clear();
  loadFileS(loc + "source/resource/modules", modules);
  modules.push_back("#include \"../module/" + lCase(m.name) + ".h\"");
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs3;
  openfile = loc + "source/resource/modules";
  fs3.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs3 << modules[i] << endl;
  fs3.close();
}

void removeFromDla (Module m, string loc)
{
  //remove from module file
  vector<string> modules;
  loadFileS(loc + "data/modules", modules);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "data/modules";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] != lCase(m.name))
      fs1 << modules[i] << endl;
  }
  fs1.close();

  //remove from module/ptrs file
  modules.clear();
  loadFileS(loc + "data/module/ptrs", modules);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs2;
  openfile = loc + "data/module/ptrs";
  fs2.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] != "#include \"" + lCase(m.name) + ".functions\"")
      fs2 << modules[i] << endl;
  }
  fs2.close();

  //remove from resource/modules
  modules.clear();
  loadFileS(loc + "source/resource/modules", modules);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs3;
  openfile = loc + "source/resource/modules";
  fs3.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] != "#include \"../module/" + lCase(m.name) + ".h\"")
      fs3 << modules[i] << endl;
  }
  fs3.close();

  //remove from users
  vector<string> users;
  loadFileS(loc + "data/users", users);
  for (size_t i = 0; i < users.size(); i++)
    removeFromUser(m, loc, users[i]);
}

void addToUser(Module m, string loc, string user)
{
  vector<string> modules;
  loadFileS(loc + "data/user/" + user + "/modules", modules);
  bool has = false;
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] == lCase(m.name))
      has = true;
  }
  if (has == false)
    modules.push_back(lCase(m.name));
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "data/user/" + user + "/modules";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs1 << modules[i] << endl;
  fs1.close();
}

void removeFromUser(Module m, string loc, string user)
{
  vector<string> modules;
  loadFileS(loc + "data/user/" + user + "/modules", modules);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "data/user/" + user + "/modules";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] != lCase(m.name))
      fs1 << modules[i] << endl;
  }
  fs1.close();

  removeUserModule(m, loc, user);
}

void addUserModule(Module m, string loc, string user)
{
  vector<string> modules;
  loadFileS(loc + "data/user/" + user + "/module/ptrs", modules);
  bool has = false;
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] == lCase(m.name))
      has = true;
  }
  if (has == false)
    modules.push_back(lCase(m.name));
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "data/user/" + user + "/module/ptrs";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++)
    fs1 << modules[i] << endl;
  fs1.close();
}

void removeUserModule(Module m, string loc, string user)
{
  vector<string> modules;
  loadFileS(loc + "data/user/" + user + "/module/ptrs", modules);
  for (size_t i = 0; i < modules.size(); i++) {
    for (size_t j = 0; j < modules.size(); j++) {
      if (modules[j] > modules[i])
        swap(modules[j], modules[i]);
    }
  }
  fstream fs1;
  string openfile = loc + "data/user/" + user + "/module/ptrs";
  fs1.open(openfile.c_str(), fstream::out);
  for (size_t i = 0; i < modules.size(); i++) {
    if (modules[i] != lCase(m.name))
      fs1 << modules[i] << endl;
  }
  fs1.close();
}


Module::Module ()
{
  Module::name = "";
  Module::description = "";
  Module::priority = 0.0;
  Module::commandCount = 0;
}

Module::Module (string modfile)
{
  if (fileExists(modfile)) {
    fstream moduleFile;
    moduleFile.open(modfile.c_str(), fstream::in);

    if (moduleFile.is_open()) {
      string tmp = "";

      getline  (moduleFile, Module::name);
      getline  (moduleFile, Module::description);
      getdouble(moduleFile, Module::priority);

      getline  (moduleFile, tmp);
      stringstream ss(tmp);
      string token;
      while (getline(ss, token, ','))
        Module::dependencies.push_back(token);

      Module::commandCount = 0;
      int nextCommand = 0;
      getint(moduleFile, nextCommand);
      while (nextCommand != 0) {
        Module::commandCount = nextCommand;

        Command tmpCommand (moduleFile);
        Module::commands.push_back(tmpCommand);

        getint(moduleFile, nextCommand);
      }

      moduleFile.close();
    }
  }
  else {
    Module::name = "";
    Module::description = "";
    Module::priority = 0.0;
    Module::commandCount = 0;
  }
}

Module::~Module ()
{
}

void Module::dump ()
{
  cout << "Name: "             << Module::name                << endl
       << "Description: "      << Module::description         << endl
       << "Priority: "         << Module::priority            << endl
       << "Dependency Count: " << Module::dependencies.size() << endl
       << "Command Count: "    << Module::commandCount        << endl;
  cout << endl;
}

Command::Command ()
{
  Command::name = "";
  Command::description = "";
  Command::definition = "";
  Command::returnType = RETURN_TYPE_DECLTYPE; 
  Command::module = "";
  Command::modulePriority = 0.0;
  Command::priority = 0.0;
  Command::modelCount = 0;
  Command::output = "";
  Command::risk = 0.0;
}

Command::Command (fstream& fs)
{
  readCommandFromFileStream(fs);
}

Command::~Command ()
{
}

void Command::readCommandFromFileStream (fstream& fs)
{
  if (fs.is_open()) {
    string tmp = "";

    getline  (fs, Command::name);
    getline  (fs, Command::description);
    getline  (fs, Command::definition);
    getint   (fs, Command::returnType);
    getline  (fs, Command::module);
    getdouble(fs, Command::modulePriority);
    getdouble(fs, Command::priority);

    Command::modelCount = 0;
    int nextModel = 0;
    getint(fs, nextModel);
    while (nextModel != 0) {
      Command::modelCount = nextModel;
      Model tmpModel;
      models.push_back(tmpModel);

      getline  (fs, models[Command::modelCount - 1].match);
      getdouble(fs, models[Command::modelCount - 1].priority);
      getint   (fs, models[Command::modelCount - 1].commandType);
      getint   (fs, models[Command::modelCount - 1].questionType);
      getint   (fs, models[Command::modelCount - 1].question);

      getint(fs, nextModel);
    }

    getline  (fs, Command::output);
    getdouble(fs, Command::risk);
  }
}
void Command::dump ()
{
  cout << "Name: "        << Command::name        << endl
       << "Description: " << Command::description << endl
       << "Definition: "  << Command::definition  << endl
       << "Return Type: " << Command::returnType  << endl
       << "Priority: "    << Command::priority    << endl
       << "Model Count: " << Command::modelCount  << endl
       << "Output: "      << Command::output      << endl
       << "Risk: "        << Command::risk        << endl;
  cout << endl;
}

void Model::dump ()
{
  cout << "Match: "         << Model::match        << endl
       << "Priority: "      << Model::priority     << endl
       << "Command Type: "  << Model::commandType  << endl
       << "Question Type: " << Model::questionType << endl
       << "Question: "      << Model::question     << endl;
  cout << endl;
}








bool getint (fstream& fs, int& outVar)
{
  if (fs.is_open()) {
    string tmp;
    fs >> outVar;
    getline(fs, tmp);
    return true;
  }
  else
    return false;
}

bool getdouble (fstream& fs, double& outVar)
{
  if (fs.is_open()) {
    string tmp;
    fs >> outVar;
    getline(fs, tmp);
    return true;
  }
  else
    return false;
}

void cls (HANDLE hConsole)
{
  COORD coordScreen = {0, 0};
  DWORD cCharsWritten;
  CONSOLE_SCREEN_BUFFER_INFO csbi; 
  DWORD dwConSize;

  GetConsoleScreenBufferInfo(hConsole, &csbi);
  dwConSize = csbi.dwSize.X * csbi.dwSize.Y;
  FillConsoleOutputCharacter(hConsole, (TCHAR) ' ', dwConSize, coordScreen, &cCharsWritten);
  GetConsoleScreenBufferInfo(hConsole, &csbi);
  FillConsoleOutputAttribute(hConsole, csbi.wAttributes, dwConSize, coordScreen, &cCharsWritten);
  SetConsoleCursorPosition(hConsole, coordScreen);
}

string uCase (string s)
{
  boost::to_upper(s);
  return s;
}
string lCase (string s)
{
  boost::to_lower(s);
  return s;
}
string str (int i)
{
  string str;
  ostringstream oss;
  oss << i;
  str = oss.str();
  return str;
}


void loadFileS (string file, vector<string>& data)
{
  string line = "";
  fstream fs;

  fs.open(file.c_str(), fstream::in);
  if (fs.is_open())
    while (getline(fs, line)) {
      data.push_back(line);
    }
  fs.close();
}