////////////////////////////////////////////////////////////////////////////////
//File:   module_editor.h
//Dir:    *
//Date:   2014-08-03
//Author: Zachary Gill
//Interface of Module Editor
////////////////////////////////////////////////////////////////////////////////


//constants
#define COMMAND_TYPE_COMMAND   1
#define COMMAND_TYPE_QUESTION  2
#define COMMAND_TYPE_STATEMENT 3

#define QUESTION_TYPE_BASIC   1
#define QUESTION_TYPE_COMPLEX 2

#define RETURN_TYPE_DECLTYPE   0
#define RETURN_TYPE_VOID       1
#define RETURN_TYPE_BOOL       2
#define RETURN_TYPE_SCHAR      3
#define RETURN_TYPE_UCHAR      4
#define RETURN_TYPE_SHORT      5
#define RETURN_TYPE_USHORT     6
#define RETURN_TYPE_INT        7
#define RETURN_TYPE_UINT       8
#define RETURN_TYPE_LONG       9
#define RETURN_TYPE_ULONG      10
#define RETURN_TYPE_LONGLONG   11
#define RETURN_TYPE_ULONGLONG  12
#define RETURN_TYPE_FLOAT      13
#define RETURN_TYPE_DOUBLE     14
#define RETURN_TYPE_LONGDOUBLE 15
#define RETURN_TYPE_CHAR       16
#define RETURN_TYPE_CHAR16_T   17
#define RETURN_TYPE_CHAR32_T   18
#define RETURN_TYPE_WCHAR_T    19
#define RETURN_TYPE_STRING     20
#define RETURN_TYPE_UDEF       21


//standard includes
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

#include <boost/filesystem.hpp>


//includes
#include "filesystem.h"


//class definitions
class Model
{
  public:
    void dump ();

    std::string match;
    double      priority;
    int         commandType;
    int         questionType;
    int         question;
} ;
class Command
{  
  public:
    Command ();
    Command (std::fstream&);
    ~Command  ();
    void readCommandFromFileStream (std::fstream&);
    void dump ();

    std::string        name;
    std::string        description;
    std::string        definition;
    int                returnType;
    std::string        module;
    double             modulePriority;
    double             priority;
    int                modelCount;
    std::vector<Model> models;
    std::string        output;
    double             risk;
} ;
class Module
{
  public:
    Module ();
    Module (std::string);
    ~Module  ();
    void dump ();

    std::string              name;
    std::string              description;
    double                   priority;
    std::vector<std::string> dependencies;
    int                      commandCount;
    std::vector<Command>     commands;
} ;


//global variable definitions
HANDLE h_  = GetStdHandle(STD_OUTPUT_HANDLE);


//function definitions
int         main             ();

void        loadLists        (std::string, std::vector<std::string>&, std::vector<std::string>&, std::vector<std::string>&);

void        backupModule     (Module, std::string, std::string);
void        saveModule       (Module, std::string, std::string, std::string);

void        makeFunctions    (Module, std::string);
void        makeCpp          (Module, std::string);
void        makeH            (Module, std::string);

void        addToDla         (Module, std::string);
void        removeFromDla    (Module, std::string);
void        addToUser        (Module, std::string, std::string);
void        removeFromUser   (Module, std::string, std::string);
void        addUserModule    (Module, std::string, std::string);
void        removeUserModule (Module, std::string, std::string);

bool        getint           (std::fstream&, int&);
bool        getdouble        (std::fstream&, double&);
void        cls              (HANDLE);
std::string uCase            (std::string);
std::string lCase            (std::string);
std::string str              (int);
void        loadFileS        (std::string, std::vector<std::string>&);