#ifndef DOUBLE_METAPHONE__H
#define DOUBLE_METAPHONE__H

#include <string>

std::string DoubleMetaphone(const std::string &str);

#endif /* DOUBLE_METAPHONE__H */