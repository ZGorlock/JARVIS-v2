////////////////////////////////////////////////////////////////////////////////
//File:   %db_V.cpp
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Implementation of %DB variable
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//includes
#include "%db_V.h"


//namespaces
using namespace std;


//functions
double is%DB(string s)
{
  const double maxScore = 100.0;

  double score = 0.0;
  //calculate score
  return score / maxScore;
}