////////////////////////////////////////////////////////////////////////////////
//File:   core.h
//Dir:    source/module/
//Date:   2014-06-08
//Author: Zachary Gill
//Interface of CORE module
////////////////////////////////////////////////////////////////////////////////


#ifndef _JARVIS_SM_CORE_H_
#define _JARVIS_SM_CORE_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>
#include <vector>


//includes
#include "../header/module.h"
#include "../header/input.h"
#include "../header/output.h"
#include "../header/settings.h"


//namespace definitions
namespace CORE
{
  std::string main           ();

  std::string clear          ();

  std::string enumSettings   ();
  std::string resetSettings  ();
  std::string revertSettings ();

  std::string log            ();
  std::string clearLog       ();

  std::string enumModules    ();
  std::string countModules   ();
  std::string enumCommands   ();
  std::string countCommands  ();
  std::string enumInputs     ();
  std::string countInputs    ();
  std::string enumOutputs    ();
  std::string countOutputs   ();

  std::string terminate      ();

  namespace PRIVATE
  {
    
  } ;
} ;


//global variable definitions
extern bool                 terminate_;
extern bool                 hide_;
extern std::string          log_;
extern int                  moduleCount_;
extern int                  inputCount_;
extern int                  outputCount_;
extern HANDLE               h_;
extern HWND                 hWnd_;
extern std::vector<Module>  modules_;
extern std::vector<Input*>  inputs_;
extern std::vector<Output*> outputs_;
extern Settings             settings_;


#endif