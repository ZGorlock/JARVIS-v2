////////////////////////////////////////////////////////////////////////////////
//File:   %nu_V.h
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Interface of %NU Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_%NU_H_
#define _DLA_SV_%NU_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double is%NU (std::string);


//shared function definitions
#include "../resource/common.h"


#endif