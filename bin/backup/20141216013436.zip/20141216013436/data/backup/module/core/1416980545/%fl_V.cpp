////////////////////////////////////////////////////////////////////////////////
//File:   %fl_V.cpp
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Implementation of %FL variable
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//includes
#include "%fl_V.h"


//namespaces
using namespace std;


//functions
double is%FL(string s)
{
  const double maxScore = 100.0;

  double score = 0.0;
  //calculate score
  return score / maxScore;
}