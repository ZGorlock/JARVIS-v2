////////////////////////////////////////////////////////////////////////////////
//File:   core.cpp
//Dir:    source/module/
//Date:   2014-04-28
//Author: Zachary Gill
//Implementation of CORE module
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <string>
#include <vector>


//includes
#include "core.h"


//namespaces
using namespace std;


//functions

string CORE::main ()
{
  return "";
}

string CORE::clear ()
{
  cls(h_);
  cout << "JARVIS" << endl << endl;
  return "";
}

string CORE::enumSettings ()
{
  settings_.dump();
  return "";
}

string CORE::resetSettings ()
{
  settings_.reset();
  return "settings reset to default";
}

string CORE::revertSettings ()
{
  loadSettings();
  return "reloading settings";
}

string CORE::log ()
{
  ShellExecute(hWnd_, "open", "log.log", NULL, "data", SW_SHOW);
  return "opening the log";
}

string CORE::clearLog ()
{
  log_.close();
  log_.open("data/log.log", fstream::out);
  log_.close();
  log_.open("data/log.log", fstream::app);
  return "clearing the log";
}

string CORE::enumModules ()
{
  for (int i = 0; i < moduleCount_; i ++)
    cout << modules_[i].getName() << endl;
  return "";
}

string CORE::countModules ()
{
  return "there are " + str(moduleCount_) + " modules installed";
}

string CORE::enumCommands ()
{
  for (int i = 0; i < moduleCount_; i ++) {
    cout << modules_[i].getName() << endl;
    for (int j = 0; j < modules_[i].getCommandCount(); j ++)
      cout << "  " << modules_[i].getCommands()[j].getName() << endl;
  }
  return "";
}

string CORE::countCommands ()
{
  int commandCount = 0;
  for (int i = 0; i < moduleCount_; i ++)
    commandCount += modules_[i].getCommandCount();
  return "there are " + str(commandCount) + " commands available";
}

string CORE::terminate ()
{
  terminate_ = true;
  return "";
}
