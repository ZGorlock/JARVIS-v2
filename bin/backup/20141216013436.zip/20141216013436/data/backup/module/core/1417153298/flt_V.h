////////////////////////////////////////////////////////////////////////////////
//File:   flt_V.h
//Dir:    source/variable/
//Date:   2014-10-21
//Author: Zachary Gill
//Interface of FLT Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_FLT_H_
#define _DLA_SV_FLT_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double isFLT (std::string);


//shared function definitions
#include "../resource/common.h"


#endif