////////////////////////////////////////////////////////////////////////////////
//File:   %in_V.h
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Interface of %IN Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_%IN_H_
#define _DLA_SV_%IN_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double is%IN (std::string);


//shared function definitions
#include "../resource/common.h"


#endif