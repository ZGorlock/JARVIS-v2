////////////////////////////////////////////////////////////////////////////////
//File:   %fl_V.h
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Interface of %FL Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_%FL_H_
#define _DLA_SV_%FL_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double is%FL (std::string);


//shared function definitions
#include "../resource/common.h"


#endif