////////////////////////////////////////////////////////////////////////////////
//File:   %in_V.cpp
//Dir:    source/variable/
//Date:   YYYY-MM-DD
//Author: Name
//Implementation of %IN variable
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//includes
#include "%in_V.h"


//namespaces
using namespace std;


//functions
double is%IN(string s)
{
  const double maxScore = 100.0;

  double score = 0.0;
  //calculate score
  return score / maxScore;
}