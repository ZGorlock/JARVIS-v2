////////////////////////////////////////////////////////////////////////////////
//File:   dbl_V.h
//Dir:    source/variable/
//Date:   2014-10-08
//Author: Zachary Gill
//Interface of DBL Variable
////////////////////////////////////////////////////////////////////////////////


#ifndef _DLA_SV_DBL_H_
#define _DLA_SV_DBL_H_


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//function definitions
double isDBL (std::string);


//shared function definitions
#include "../resource/common.h"


#endif