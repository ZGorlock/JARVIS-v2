////////////////////////////////////////////////////////////////////////////////
//File:   int_V.cpp
//Dir:    source/variable/
//Date:   2014-10-21
//Author: Zachary Gill
//Implementation of INT variable
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes
#include <string>


//includes
#include "int_V.h"


//namespaces
using namespace std;


//functions
double isINT (string s)
{
  const double maxScore = 100.0;

  double score = 0.0;
  int value = val(s);
  double valueD = vald(s);
  string restr = str(value);
  if (value > 0 || str_is_0(s))
    score += 30.0;
  if ((double)value == valueD)
    score += 20.0;
  int sizeDif = abs((int)(restr.length() - s.length()));
  if (sizeDif == 0)
    score += 50.0;
  else
    score += 25.0 / sizeDif;
  return score / maxScore;
}