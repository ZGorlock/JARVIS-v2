////////////////////////////////////////////////////////////////////////////////
//File:   poop.h
//Dir:    source/module/
//Date:   YYYY-MM-DD
//Author: Zachary Gill
//Interface of POOP module
////////////////////////////////////////////////////////////////////////////////


#ifndef _JARVIS_SM_POOP_H_
#define _JARVIS_SM_POOP_H_


//constants
#include "../resource/const.h"


//standard includes


//includes


//namespace defintions
namespace POOP
{
  std::string main ();
  int         test ();
  double      anotherTest();
  std::string something      ();

  namespace PRIVATE
  {

  } ;
} ;


//global variable definitions


#endif