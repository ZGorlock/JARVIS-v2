////////////////////////////////////////////////////////////////////////////////
//File:   poop.cpp
//Dir:    source/module/
//Date:   YYYY-MM-DD
//Author: Zachary Gill
//Implementation of POOP module
////////////////////////////////////////////////////////////////////////////////


//constants
#include "../resource/const.h"


//standard includes


//includes
#include "poop.h"


//namespaces
using namespace std;


//functions

string POOP::main ()
{
  return "";
}

